package com.cruiseline.exception;

public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String message) {
        super(message);
    }
    public ResourceNotFoundException(String resource, String field, Object value) {
        super("%s not found with %s = '%s'".formatted(resource, field, value));
    }
}
