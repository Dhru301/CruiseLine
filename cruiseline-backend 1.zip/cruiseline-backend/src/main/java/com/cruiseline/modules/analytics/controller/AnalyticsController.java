package com.cruiseline.modules.analytics.controller;

import com.cruiseline.common.dto.ApiResponse;
import com.cruiseline.modules.analytics.dto.VoyageAnalyticsResponse;
import com.cruiseline.modules.analytics.service.AnalyticsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@Tag(name = "Voyage Analytics", description = "Occupancy, revenue and excursion uptake dashboards")
@RestController
@RequestMapping("/api/analytics")
@PreAuthorize("hasRole('ADMIN')")
public class AnalyticsController {

    private final AnalyticsService analyticsService;

    @Operation(summary = "Get KPI dashboard for a voyage (ADMIN only)")
    @GetMapping("/voyage/{voyageId}")
    public ApiResponse<VoyageAnalyticsResponse> voyage(@PathVariable Long voyageId) {
        return ApiResponse.ok(analyticsService.voyageAnalytics(voyageId));
    }

    public AnalyticsController(AnalyticsService analyticsService) {
        this.analyticsService = analyticsService;
    }

}
