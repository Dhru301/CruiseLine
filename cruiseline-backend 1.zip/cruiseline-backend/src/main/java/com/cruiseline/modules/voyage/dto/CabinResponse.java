package com.cruiseline.modules.voyage.dto;

import com.cruiseline.common.enums.CabinLocation;
import com.cruiseline.common.enums.CabinStatus;
import com.cruiseline.modules.voyage.entity.Cabin;

public class CabinResponse {
    private Long cabinId;
    private Long categoryId;
    private String cabinNumber;
    private String deck;
    private CabinLocation location;
    private CabinStatus status;

    public static CabinResponse from(Cabin c) {
        return CabinResponse.builder()
                .cabinId(c.getCabinId())
                .categoryId(c.getCategory().getCategoryId())
                .cabinNumber(c.getCabinNumber())
                .deck(c.getDeck())
                .location(c.getLocation())
                .status(c.getStatus())
                .build();
    }

    public CabinResponse() {
    }

    public CabinResponse(Long cabinId, Long categoryId, String cabinNumber, String deck, CabinLocation location, CabinStatus status) {
        this.cabinId = cabinId;
        this.categoryId = categoryId;
        this.cabinNumber = cabinNumber;
        this.deck = deck;
        this.location = location;
        this.status = status;
    }

    public Long getCabinId() {
        return this.cabinId;
    }

    public Long getCategoryId() {
        return this.categoryId;
    }

    public String getCabinNumber() {
        return this.cabinNumber;
    }

    public String getDeck() {
        return this.deck;
    }

    public CabinLocation getLocation() {
        return this.location;
    }

    public CabinStatus getStatus() {
        return this.status;
    }

    public void setCabinId(Long cabinId) {
        this.cabinId = cabinId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public void setCabinNumber(String cabinNumber) {
        this.cabinNumber = cabinNumber;
    }

    public void setDeck(String deck) {
        this.deck = deck;
    }

    public void setLocation(CabinLocation location) {
        this.location = location;
    }

    public void setStatus(CabinStatus status) {
        this.status = status;
    }

    public static CabinResponseBuilder builder() {
        return new CabinResponseBuilder();
    }

    public static class CabinResponseBuilder {
        private Long cabinId;
        private Long categoryId;
        private String cabinNumber;
        private String deck;
        private CabinLocation location;
        private CabinStatus status;

        public CabinResponseBuilder cabinId(Long cabinId) {
            this.cabinId = cabinId;
            return this;
        }
        public CabinResponseBuilder categoryId(Long categoryId) {
            this.categoryId = categoryId;
            return this;
        }
        public CabinResponseBuilder cabinNumber(String cabinNumber) {
            this.cabinNumber = cabinNumber;
            return this;
        }
        public CabinResponseBuilder deck(String deck) {
            this.deck = deck;
            return this;
        }
        public CabinResponseBuilder location(CabinLocation location) {
            this.location = location;
            return this;
        }
        public CabinResponseBuilder status(CabinStatus status) {
            this.status = status;
            return this;
        }

        public CabinResponse build() {
            CabinResponse instance = new CabinResponse();
            instance.cabinId = this.cabinId;
            instance.categoryId = this.categoryId;
            instance.cabinNumber = this.cabinNumber;
            instance.deck = this.deck;
            instance.location = this.location;
            instance.status = this.status;
            return instance;
        }
    }

}
