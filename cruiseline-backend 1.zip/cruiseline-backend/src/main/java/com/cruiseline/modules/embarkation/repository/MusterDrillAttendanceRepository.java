package com.cruiseline.modules.embarkation.repository;

import com.cruiseline.modules.embarkation.entity.MusterDrillAttendance;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MusterDrillAttendanceRepository extends JpaRepository<MusterDrillAttendance, Long> {
    List<MusterDrillAttendance> findByVoyageId(Long voyageId);
}
