package com.cruiseline.modules.excursion.service;

import com.cruiseline.common.audit.AuditService;
import com.cruiseline.common.dto.PagedResponse;
import com.cruiseline.common.enums.NotificationCategory;
import com.cruiseline.common.enums.BookingStatus;
import com.cruiseline.common.enums.ExcursionBookingStatus;
import com.cruiseline.common.enums.ExcursionStatus;
import com.cruiseline.common.enums.ManifestStatus;
import com.cruiseline.exception.BusinessRuleException;
import com.cruiseline.exception.DuplicateResourceException;
import com.cruiseline.exception.ResourceNotFoundException;
import com.cruiseline.modules.excursion.dto.*;
import com.cruiseline.modules.excursion.entity.ExcursionBooking;
import com.cruiseline.modules.excursion.entity.ExcursionManifest;
import com.cruiseline.modules.excursion.entity.ShoreExcursion;
import com.cruiseline.modules.excursion.repository.ExcursionBookingRepository;
import com.cruiseline.modules.excursion.repository.ExcursionManifestRepository;
import com.cruiseline.modules.excursion.repository.ShoreExcursionRepository;
import com.cruiseline.modules.booking.repository.CruiseBookingRepository;
import com.cruiseline.modules.notification.service.NotificationService;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
public class ExcursionService {

    private final ShoreExcursionRepository excursionRepository;
    private final ExcursionBookingRepository bookingRepository;
    private final ExcursionManifestRepository manifestRepository;
    private final AuditService auditService;
    private final NotificationService notificationService;
    private final CruiseBookingRepository cruiseBookingRepository;

    // ---- Catalog ----

    @Transactional
    public ExcursionResponse createExcursion(ExcursionRequest req) {
        ShoreExcursion e = ShoreExcursion.builder()
                .portOfCall(req.getPortOfCall())
                .excursionName(req.getExcursionName())
                .category(req.getCategory())
                .durationHours(req.getDurationHours())
                .price(req.getPrice())
                .maxCapacity(req.getMaxCapacity())
                .bookedCount(0)
                .difficultyLevel(req.getDifficultyLevel())
                .status(ExcursionStatus.AVAILABLE)
                .build();
        return ExcursionResponse.from(excursionRepository.save(e));
    }

    @Transactional(readOnly = true)
    public PagedResponse<ExcursionResponse> listExcursions(String portOfCall, Pageable pageable) {
        var page = (portOfCall == null || portOfCall.isBlank())
                ? excursionRepository.findAll(pageable).map(ExcursionResponse::from)
                : excursionRepository.findByPortOfCall(portOfCall, pageable).map(ExcursionResponse::from);
        return PagedResponse.from(page);
    }

    @Transactional(readOnly = true)
    public ExcursionResponse getExcursion(Long id) {
        return ExcursionResponse.from(findExcursion(id));
    }

    @Transactional
    public ExcursionResponse updateExcursion(Long id, ExcursionRequest req) {
        ShoreExcursion e = findExcursion(id);
        e.setPortOfCall(req.getPortOfCall());
        e.setExcursionName(req.getExcursionName());
        e.setCategory(req.getCategory());
        e.setDurationHours(req.getDurationHours());
        e.setPrice(req.getPrice());
        e.setMaxCapacity(req.getMaxCapacity());
        e.setDifficultyLevel(req.getDifficultyLevel());
        return ExcursionResponse.from(e);
    }

    // ---- Bookings ----

    @Transactional
    public ExcursionBookingResponse book(ExcursionBookingRequest req) {
        if (!cruiseBookingRepository.existsByLeadPassengerIdAndVoyageIdAndStatusNot(
                req.getPassengerId(), req.getVoyageId(), BookingStatus.CANCELLED)) {
            throw new BusinessRuleException(
                "Passenger has no booking on this voyage; book a cabin before booking an excursion");
        }
        ShoreExcursion e = findExcursion(req.getExcursionId());
        if (e.getStatus() != ExcursionStatus.AVAILABLE) {
            throw new BusinessRuleException("Excursion is not available for booking");
        }
        if (e.getBookedCount() >= e.getMaxCapacity()) {
            throw new BusinessRuleException("Excursion is fully booked");
        }

        ExcursionBooking booking = ExcursionBooking.builder()
                .excursionId(e.getExcursionId())
                .passengerId(req.getPassengerId())
                .voyageId(req.getVoyageId())
                .bookingDate(LocalDate.now())
                .price(e.getPrice())
                .status(ExcursionBookingStatus.BOOKED)
                .build();
        booking = bookingRepository.save(booking);

        e.setBookedCount(e.getBookedCount() + 1);
        if (e.getBookedCount() >= e.getMaxCapacity()) {
            e.setStatus(ExcursionStatus.SOLD_OUT);
        }
        auditService.record("EXCURSION_BOOKED", "ExcursionBooking");
        notificationService.notify(booking.getPassengerId(),
            "You've booked the excursion '" + e.getExcursionName() + "' for $" + e.getPrice() + ".",
            NotificationCategory.EXCURSION);
        return ExcursionBookingResponse.from(booking);
    }

    @Transactional
    public ExcursionBookingResponse cancelBooking(Long bookingId) {
        ExcursionBooking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("ExcursionBooking", "id", bookingId));
        if (booking.getStatus() == ExcursionBookingStatus.CANCELLED) {
            throw new BusinessRuleException("Booking is already cancelled");
        }
        booking.setStatus(ExcursionBookingStatus.CANCELLED);

        ShoreExcursion e = findExcursion(booking.getExcursionId());
        e.setBookedCount(Math.max(0, e.getBookedCount() - 1));
        if (e.getStatus() == ExcursionStatus.SOLD_OUT) {
            e.setStatus(ExcursionStatus.AVAILABLE);
        }
        auditService.record("EXCURSION_BOOKING_CANCELLED", "ExcursionBooking");
        return ExcursionBookingResponse.from(booking);
    }

    @Transactional(readOnly = true)
    public PagedResponse<ExcursionBookingResponse> passengerBookings(Long passengerId, Pageable pageable) {
        var page = bookingRepository.findByPassengerId(passengerId, pageable)
                .map(ExcursionBookingResponse::from);
        return PagedResponse.from(page);
    }

    // ---- Manifests ----

    @Transactional
    public ManifestResponse generateManifest(ManifestRequest req) {
        if (manifestRepository.existsByExcursionIdAndVoyageId(req.getExcursionId(), req.getVoyageId())) {
            throw new DuplicateResourceException("A manifest already exists for this excursion on this voyage");
        }
        List<ExcursionBooking> bookings = bookingRepository.findByExcursionId(req.getExcursionId());
        int booked = (int) bookings.stream()
                .filter(b -> b.getStatus() == ExcursionBookingStatus.BOOKED)
                .count();

        ExcursionManifest manifest = ExcursionManifest.builder()
                .excursionId(req.getExcursionId())
                .voyageId(req.getVoyageId())
                .portDate(req.getPortDate())
                .totalBooked(booked)
                .meetingPoint(req.getMeetingPoint())
                .departureTime(req.getDepartureTime())
                .status(ManifestStatus.DRAFT)
                .build();
        auditService.record("MANIFEST_GENERATED", "ExcursionManifest");
        return ManifestResponse.from(manifestRepository.save(manifest));
    }

    @Transactional
    public ManifestResponse finaliseManifest(Long manifestId) {
        ExcursionManifest m = manifestRepository.findById(manifestId)
                .orElseThrow(() -> new ResourceNotFoundException("ExcursionManifest", "id", manifestId));
        m.setStatus(ManifestStatus.FINALISED);

        // Alert every booked passenger of the meeting point and departure time.
        ShoreExcursion e = findExcursion(m.getExcursionId());
        String msg = "Meeting point for '" + e.getExcursionName() + "': " + m.getMeetingPoint()
                + ", departs " + m.getDepartureTime() + " on " + m.getPortDate() + ".";
        bookingRepository.findByExcursionId(m.getExcursionId()).stream()
                .filter(b -> b.getStatus() == ExcursionBookingStatus.BOOKED
                        && b.getVoyageId().equals(m.getVoyageId()))
                .forEach(b -> notificationService.notify(b.getPassengerId(), msg, NotificationCategory.EXCURSION));

        return ManifestResponse.from(m);
    }

    @Transactional(readOnly = true)
    public List<ManifestResponse> manifestsByVoyage(Long voyageId) {
        return manifestRepository.findByVoyageId(voyageId).stream()
                .map(ManifestResponse::from).toList();
    }

    private ShoreExcursion findExcursion(Long id) {
        return excursionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ShoreExcursion", "id", id));
    }

    public ExcursionService(ShoreExcursionRepository excursionRepository, ExcursionBookingRepository bookingRepository, ExcursionManifestRepository manifestRepository, AuditService auditService, NotificationService notificationService, CruiseBookingRepository cruiseBookingRepository) {
        this.excursionRepository = excursionRepository;
        this.bookingRepository = bookingRepository;
        this.manifestRepository = manifestRepository;
        this.auditService = auditService;
        this.notificationService = notificationService;
        this.cruiseBookingRepository = cruiseBookingRepository;
    }

}