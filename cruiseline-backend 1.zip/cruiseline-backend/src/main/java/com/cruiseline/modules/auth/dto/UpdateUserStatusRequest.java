package com.cruiseline.modules.auth.dto;

import com.cruiseline.common.enums.UserStatus;
import jakarta.validation.constraints.NotNull;

public class UpdateUserStatusRequest {
    @NotNull
    private UserStatus status;

    public UserStatus getStatus() {
        return this.status;
    }

    public void setStatus(UserStatus status) {
        this.status = status;
    }

}
