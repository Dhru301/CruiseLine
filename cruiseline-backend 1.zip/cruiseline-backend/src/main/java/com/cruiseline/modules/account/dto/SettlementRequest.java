package com.cruiseline.modules.account.dto;

import com.cruiseline.common.enums.PaymentMode;
import jakarta.validation.constraints.NotNull;

public class SettlementRequest {
    @NotNull
    private Long accountId;
    @NotNull
    private PaymentMode paymentMode;

    public Long getAccountId() {
        return this.accountId;
    }

    public PaymentMode getPaymentMode() {
        return this.paymentMode;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public void setPaymentMode(PaymentMode paymentMode) {
        this.paymentMode = paymentMode;
    }

}
