package com.cruiseline.modules.voyage.repository;

import com.cruiseline.common.enums.VoyageStatus;
import com.cruiseline.modules.voyage.entity.Voyage;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VoyageRepository extends JpaRepository<Voyage, Long> {
    Page<Voyage> findByStatus(VoyageStatus status, Pageable pageable);
    Page<Voyage> findByVesselId(String vesselId, Pageable pageable);
}
