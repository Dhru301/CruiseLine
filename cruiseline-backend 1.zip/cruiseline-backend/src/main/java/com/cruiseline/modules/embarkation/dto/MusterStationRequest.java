package com.cruiseline.modules.embarkation.dto;

import jakarta.validation.constraints.*;

public class MusterStationRequest {
    @NotNull
    private Long voyageId;
    @NotBlank
    private String stationCode;
    private String deck;
    private String assignedCabinRange;
    @NotNull @Min(1)
    private Integer capacity;

    public Long getVoyageId() {
        return this.voyageId;
    }

    public String getStationCode() {
        return this.stationCode;
    }

    public String getDeck() {
        return this.deck;
    }

    public String getAssignedCabinRange() {
        return this.assignedCabinRange;
    }

    public Integer getCapacity() {
        return this.capacity;
    }

    public void setVoyageId(Long voyageId) {
        this.voyageId = voyageId;
    }

    public void setStationCode(String stationCode) {
        this.stationCode = stationCode;
    }

    public void setDeck(String deck) {
        this.deck = deck;
    }

    public void setAssignedCabinRange(String assignedCabinRange) {
        this.assignedCabinRange = assignedCabinRange;
    }

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

}
