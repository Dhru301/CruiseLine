package com.cruiseline.modules.excursion.dto;

import jakarta.validation.constraints.NotNull;

public class ExcursionBookingRequest {
    @NotNull
    private Long excursionId;
    @NotNull
    private Long passengerId;
    @NotNull
    private Long voyageId;

    public Long getExcursionId() {
        return this.excursionId;
    }

    public Long getPassengerId() {
        return this.passengerId;
    }

    public Long getVoyageId() {
        return this.voyageId;
    }

    public void setExcursionId(Long excursionId) {
        this.excursionId = excursionId;
    }

    public void setPassengerId(Long passengerId) {
        this.passengerId = passengerId;
    }

    public void setVoyageId(Long voyageId) {
        this.voyageId = voyageId;
    }

}
