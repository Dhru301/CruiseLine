package com.cruiseline.modules.account.controller;

import com.cruiseline.common.dto.ApiResponse;
import com.cruiseline.config.UserPrincipal;
import com.cruiseline.modules.account.dto.*;
import com.cruiseline.modules.account.service.AccountService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "Onboard Account & Charges", description = "Passenger folios, charges and settlement")
@RestController
@RequestMapping("/api/accounts")
public class AccountController {

    private final AccountService accountService;

    @Operation(summary = "Open an onboard account (PURSER/ADMIN)")
    @PostMapping
    @PreAuthorize("hasAnyRole('PURSER','ADMIN')")
    public ResponseEntity<ApiResponse<AccountResponse>> open(@Valid @RequestBody CreateAccountRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Account opened", accountService.openAccount(req)));
    }

    @Operation(summary = "View an onboard account (folio)")
    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('PURSER','ADMIN','PASSENGER')")
    public ApiResponse<AccountResponse> get(@PathVariable Long id) {
        return ApiResponse.ok(accountService.getAccount(id));
    }

    @Operation(summary = "Post a charge to an account (PURSER/ONBOARD_AGENT/ADMIN)")
    @PostMapping("/charges")
    @PreAuthorize("hasAnyRole('PURSER','ONBOARD_AGENT','ADMIN')")
    public ResponseEntity<ApiResponse<ChargeResponse>> postCharge(@AuthenticationPrincipal UserPrincipal principal,
                                                                @Valid @RequestBody ChargeRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Charge posted", accountService.postCharge(principal.getUserId(), req)));
    }

    @Operation(summary = "Reverse a charge (PURSER/ADMIN)")
    @PatchMapping("/charges/{chargeId}/reverse")
    @PreAuthorize("hasAnyRole('PURSER','ADMIN')")
    public ApiResponse<ChargeResponse> reverse(@PathVariable Long chargeId) {
        return ApiResponse.ok("Charge reversed", accountService.reverseCharge(chargeId));
    }

    @Operation(summary = "List charges on an account")
    @GetMapping("/{accountId}/charges")
    @PreAuthorize("hasAnyRole('PURSER','ADMIN','PASSENGER')")
    public ApiResponse<List<ChargeResponse>> charges(@PathVariable Long accountId) {
        return ApiResponse.ok(accountService.listCharges(accountId));
    }

    @Operation(summary = "Settle a folio at voyage end (PURSER/ADMIN)")
    @PostMapping("/settlements")
    @PreAuthorize("hasAnyRole('PURSER','ADMIN')")
    public ResponseEntity<ApiResponse<SettlementResponse>> settle(@Valid @RequestBody SettlementRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Folio settled", accountService.settle(req)));
    }

    public AccountController(AccountService accountService) {
        this.accountService = accountService;
    }

}
