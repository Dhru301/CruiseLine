package com.cruiseline.modules.excursion.dto;

import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;
import java.time.LocalTime;

public class ManifestRequest {
    @NotNull
    private Long excursionId;
    @NotNull
    private Long voyageId;
    private LocalDate portDate;
    private String meetingPoint;
    private LocalTime departureTime;

    public Long getExcursionId() {
        return this.excursionId;
    }

    public Long getVoyageId() {
        return this.voyageId;
    }

    public LocalDate getPortDate() {
        return this.portDate;
    }

    public String getMeetingPoint() {
        return this.meetingPoint;
    }

    public LocalTime getDepartureTime() {
        return this.departureTime;
    }

    public void setExcursionId(Long excursionId) {
        this.excursionId = excursionId;
    }

    public void setVoyageId(Long voyageId) {
        this.voyageId = voyageId;
    }

    public void setPortDate(LocalDate portDate) {
        this.portDate = portDate;
    }

    public void setMeetingPoint(String meetingPoint) {
        this.meetingPoint = meetingPoint;
    }

    public void setDepartureTime(LocalTime departureTime) {
        this.departureTime = departureTime;
    }

}
