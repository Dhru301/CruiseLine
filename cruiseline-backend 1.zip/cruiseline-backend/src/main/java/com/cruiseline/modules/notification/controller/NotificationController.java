package com.cruiseline.modules.notification.controller;

import com.cruiseline.common.dto.ApiResponse;
import com.cruiseline.common.dto.PagedResponse;
import com.cruiseline.common.enums.NotificationStatus;
import com.cruiseline.config.UserPrincipal;
import com.cruiseline.modules.notification.dto.NotificationRequest;
import com.cruiseline.modules.notification.dto.NotificationResponse;
import com.cruiseline.modules.notification.service.NotificationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@Tag(name = "Notifications & Alerts", description = "In-app notifications per user")
@RestController
@RequestMapping("/api/notifications")
public class NotificationController {

    private final NotificationService notificationService;

    @Operation(summary = "Create a notification for a user (staff/ADMIN)")
    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','PURSER','EMBARKATION_OFFICER','ONBOARD_AGENT','EXCURSION_COORDINATOR')")
    public ResponseEntity<ApiResponse<NotificationResponse>> create(@Valid @RequestBody NotificationRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Notification created", notificationService.create(req)));
    }

    @Operation(summary = "List my notifications (optional status filter)")
    @GetMapping("/me")
    public ApiResponse<PagedResponse<NotificationResponse>> myNotifications(
            @AuthenticationPrincipal UserPrincipal principal,
            @RequestParam(required = false) NotificationStatus status,
            Pageable pageable) {
        return ApiResponse.ok(notificationService.list(principal.getUserId(), status, pageable));
    }

    @Operation(summary = "Count my unread notifications")
    @GetMapping("/me/unread-count")
    public ApiResponse<Long> unreadCount(@AuthenticationPrincipal UserPrincipal principal) {
        return ApiResponse.ok(notificationService.unreadCount(principal.getUserId()));
    }

    @Operation(summary = "Mark a notification as read")
    @PatchMapping("/{id}/read")
    public ApiResponse<NotificationResponse> markRead(@PathVariable Long id,
                                                    @AuthenticationPrincipal UserPrincipal principal) {
        return ApiResponse.ok(notificationService.markRead(id, principal.getUserId()));
    }

    @Operation(summary = "Dismiss a notification")
    @PatchMapping("/{id}/dismiss")
    public ApiResponse<NotificationResponse> dismiss(@PathVariable Long id,
                                                   @AuthenticationPrincipal UserPrincipal principal) {
        return ApiResponse.ok(notificationService.dismiss(id, principal.getUserId()));
    }

    public NotificationController(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

}
