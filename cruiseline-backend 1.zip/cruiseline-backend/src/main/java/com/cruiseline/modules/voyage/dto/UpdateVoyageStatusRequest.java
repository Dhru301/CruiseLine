package com.cruiseline.modules.voyage.dto;

import com.cruiseline.common.enums.VoyageStatus;
import jakarta.validation.constraints.NotNull;

public class UpdateVoyageStatusRequest {
    @NotNull
    private VoyageStatus status;

    public VoyageStatus getStatus() {
        return this.status;
    }

    public void setStatus(VoyageStatus status) {
        this.status = status;
    }

}
