package com.cruiseline.modules.auth.controller;

import com.cruiseline.common.dto.ApiResponse;
import com.cruiseline.common.dto.PagedResponse;
import com.cruiseline.common.enums.Role;
import com.cruiseline.config.UserPrincipal;
import com.cruiseline.modules.auth.dto.RegisterRequest;
import com.cruiseline.modules.auth.dto.UpdateUserStatusRequest;
import com.cruiseline.modules.auth.dto.UserResponse;
import com.cruiseline.modules.auth.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.data.domain.Pageable;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@Tag(name = "User Management", description = "Admin user administration and current-user profile")
@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;

    @Operation(summary = "Get the currently authenticated user's profile")
    @GetMapping("/me")
    public ApiResponse<UserResponse> me(@AuthenticationPrincipal UserPrincipal principal) {
        return ApiResponse.ok(userService.getUser(principal.getUserId()));
    }

    @Operation(summary = "Create a user with any role (ADMIN only)")
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ApiResponse<UserResponse> create(@Valid @RequestBody RegisterRequest req) {
        return ApiResponse.ok("User created", userService.createUser(req));
    }

    @Operation(summary = "List users, optionally filtered by role (ADMIN only)")
    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ApiResponse<PagedResponse<UserResponse>> list(@RequestParam(required = false) Role role,
                                                         Pageable pageable) {
        return ApiResponse.ok(userService.listUsers(role, pageable));
    }

    @Operation(summary = "Directory of users for selection pickers (staff roles). "
            + "Optionally filtered by role, e.g. ?role=PASSENGER.")
    @GetMapping("/directory")
    @PreAuthorize("hasAnyRole('ADMIN','PURSER','EMBARKATION_OFFICER','ONBOARD_AGENT','EXCURSION_COORDINATOR')")
    public ApiResponse<PagedResponse<UserResponse>> directory(@RequestParam(required = false) Role role,
                                                              Pageable pageable) {
        return ApiResponse.ok(userService.listUsers(role, pageable));
    }

    @Operation(summary = "Get a user by id (ADMIN only)")
    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ApiResponse<UserResponse> get(@PathVariable Long id) {
        return ApiResponse.ok(userService.getUser(id));
    }

    @Operation(summary = "Activate or deactivate a user (ADMIN only)")
    @PatchMapping("/{id}/status")
    @PreAuthorize("hasRole('ADMIN')")
    public ApiResponse<UserResponse> updateStatus(@PathVariable Long id,
                                                  @Valid @RequestBody UpdateUserStatusRequest req) {
        return ApiResponse.ok("Status updated", userService.updateStatus(id, req));
    }

    public UserController(UserService userService) {
        this.userService = userService;
    }

}