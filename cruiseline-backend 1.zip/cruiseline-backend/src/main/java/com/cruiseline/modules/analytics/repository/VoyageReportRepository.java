package com.cruiseline.modules.analytics.repository;

import com.cruiseline.modules.analytics.entity.VoyageReport;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VoyageReportRepository extends JpaRepository<VoyageReport, Long> {
}
