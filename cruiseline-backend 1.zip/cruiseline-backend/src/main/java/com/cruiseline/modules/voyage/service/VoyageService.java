package com.cruiseline.modules.voyage.service;

import com.cruiseline.common.audit.AuditService;
import com.cruiseline.common.dto.PagedResponse;
import com.cruiseline.common.enums.CabinStatus;
import com.cruiseline.common.enums.CategoryStatus;
import com.cruiseline.common.enums.VoyageStatus;
import com.cruiseline.exception.BadRequestException;
import com.cruiseline.exception.ResourceNotFoundException;
import com.cruiseline.modules.voyage.dto.*;
import com.cruiseline.modules.voyage.entity.Cabin;
import com.cruiseline.modules.voyage.entity.CabinCategory;
import com.cruiseline.modules.voyage.entity.Voyage;
import com.cruiseline.modules.voyage.repository.CabinCategoryRepository;
import com.cruiseline.modules.voyage.repository.CabinRepository;
import com.cruiseline.modules.voyage.repository.VoyageRepository;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class VoyageService {

    private final VoyageRepository voyageRepository;
    private final CabinCategoryRepository categoryRepository;
    private final CabinRepository cabinRepository;
    private final AuditService auditService;

    // ---- Voyages ----

    @Transactional
    public VoyageResponse createVoyage(VoyageRequest req) {
        if (req.getReturnDate().isBefore(req.getDepartureDate())) {
            throw new BadRequestException("Return date cannot be before departure date");
        }
        Voyage voyage = Voyage.builder()
                .voyageName(req.getVoyageName())
                .vesselId(req.getVesselId())
                .homePort(req.getHomePort())
                .departureDate(req.getDepartureDate())
                .returnDate(req.getReturnDate())
                .durationNights(req.getDurationNights())
                .portsOfCall(req.getPortsOfCall())
                .status(req.getStatus() == null ? VoyageStatus.PLANNING : req.getStatus())
                .build();
        voyage = voyageRepository.save(voyage);
        auditService.record("VOYAGE_CREATED", "Voyage");
        return VoyageResponse.from(voyage);
    }

    @Transactional(readOnly = true)
    public PagedResponse<VoyageResponse> listVoyages(VoyageStatus status, Pageable pageable) {
        var page = (status == null)
                ? voyageRepository.findAll(pageable).map(VoyageResponse::from)
                : voyageRepository.findByStatus(status, pageable).map(VoyageResponse::from);
        return PagedResponse.from(page);
    }

    @Transactional(readOnly = true)
    public VoyageResponse getVoyage(Long id) {
        return VoyageResponse.from(findVoyage(id));
    }

    @Transactional
    public VoyageResponse updateVoyage(Long id, VoyageRequest req) {
        Voyage voyage = findVoyage(id);
        voyage.setVoyageName(req.getVoyageName());
        voyage.setVesselId(req.getVesselId());
        voyage.setHomePort(req.getHomePort());
        voyage.setDepartureDate(req.getDepartureDate());
        voyage.setReturnDate(req.getReturnDate());
        voyage.setDurationNights(req.getDurationNights());
        voyage.setPortsOfCall(req.getPortsOfCall());
        if (req.getStatus() != null) {
            validateTransition(voyage.getStatus(), req.getStatus());
            voyage.setStatus(req.getStatus());
        }
        auditService.record("VOYAGE_UPDATED", "Voyage");
        return VoyageResponse.from(voyage);
    }

    @Transactional
    public VoyageResponse updateStatus(Long id, UpdateVoyageStatusRequest req) {
        Voyage voyage = findVoyage(id);
        validateTransition(voyage.getStatus(), req.getStatus());
        voyage.setStatus(req.getStatus());
        auditService.record("VOYAGE_STATUS_UPDATED", "Voyage");
        return VoyageResponse.from(voyage);
    }

    // ---- Cabin categories ----

    @Transactional
    public CabinCategoryResponse addCategory(CabinCategoryRequest req) {
        Voyage voyage = findVoyage(req.getVoyageId());
        CabinCategory category = CabinCategory.builder()
                .voyage(voyage)
                .categoryName(req.getCategoryName())
                .deck(req.getDeck())
                .beddingConfig(req.getBeddingConfig())
                .maxOccupancy(req.getMaxOccupancy())
                .basePrice(req.getBasePrice())
                .totalCabins(req.getTotalCabins())
                .availableCabins(req.getTotalCabins())
                .status(CategoryStatus.AVAILABLE)
                .build();
        category = categoryRepository.save(category);
        return CabinCategoryResponse.from(category);
    }

    @Transactional(readOnly = true)
    public List<CabinCategoryResponse> listCategories(Long voyageId) {
        return categoryRepository.findByVoyageVoyageId(voyageId).stream()
                .map(CabinCategoryResponse::from)
                .toList();
    }

    // ---- Cabins ----

    @Transactional
    public CabinResponse addCabin(CabinRequest req) {
        CabinCategory category = categoryRepository.findById(req.getCategoryId())
                .orElseThrow(() -> new ResourceNotFoundException("CabinCategory", "id", req.getCategoryId()));
        Cabin cabin = Cabin.builder()
                .category(category)
                .cabinNumber(req.getCabinNumber())
                .deck(req.getDeck())
                .location(req.getLocation())
                .status(CabinStatus.AVAILABLE)
                .build();
        cabin = cabinRepository.save(cabin);
        return CabinResponse.from(cabin);
    }

    @Transactional(readOnly = true)
    public List<CabinResponse> listCabins(Long categoryId) {
        return cabinRepository.findByCategoryCategoryId(categoryId).stream()
                .map(CabinResponse::from)
                .toList();
    }

    private void validateTransition(VoyageStatus current, VoyageStatus next) {
        if (current == next) return;
        if (current == VoyageStatus.COMPLETED || current == VoyageStatus.CANCELLED) {
            throw new BadRequestException("Voyage is " + current + " and its status can no longer change");
        }
        if (next == VoyageStatus.CANCELLED) return;
        if (rank(next) < rank(current)) {
            throw new BadRequestException("Cannot move voyage status backward from " + current + " to " + next);
        }
    }

    private int rank(VoyageStatus s) {
        switch (s) {
            case PLANNING: return 0;
            case OPEN: return 1;
            case SAILING: return 2;
            case COMPLETED: return 3;
            default: return 99;
        }
    }

    private Voyage findVoyage(Long id) {
        return voyageRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Voyage", "id", id));
    }

    public VoyageService(VoyageRepository voyageRepository, CabinCategoryRepository categoryRepository, CabinRepository cabinRepository, AuditService auditService) {
        this.voyageRepository = voyageRepository;
        this.categoryRepository = categoryRepository;
        this.cabinRepository = cabinRepository;
        this.auditService = auditService;
    }

}