package com.cruiseline.modules.analytics.dto;


import java.math.BigDecimal;

public class VoyageAnalyticsResponse {
    private Long voyageId;
    private double occupancyRate;        // % of cabins sold
    private BigDecimal totalRevenue;     // booking revenue
    private BigDecimal revenuePerPassenger;
    private double excursionUptakeRate;  // excursion bookings per passenger
    private BigDecimal onboardSpendAvg;  // avg onboard charges per passenger
    private long totalBookings;
    private long totalPassengers;

    public VoyageAnalyticsResponse() {
    }

    public VoyageAnalyticsResponse(Long voyageId, double occupancyRate, BigDecimal totalRevenue, BigDecimal revenuePerPassenger, double excursionUptakeRate, BigDecimal onboardSpendAvg, long totalBookings, long totalPassengers) {
        this.voyageId = voyageId;
        this.occupancyRate = occupancyRate;
        this.totalRevenue = totalRevenue;
        this.revenuePerPassenger = revenuePerPassenger;
        this.excursionUptakeRate = excursionUptakeRate;
        this.onboardSpendAvg = onboardSpendAvg;
        this.totalBookings = totalBookings;
        this.totalPassengers = totalPassengers;
    }

    public Long getVoyageId() {
        return this.voyageId;
    }

    public double getOccupancyRate() {
        return this.occupancyRate;
    }

    public BigDecimal getTotalRevenue() {
        return this.totalRevenue;
    }

    public BigDecimal getRevenuePerPassenger() {
        return this.revenuePerPassenger;
    }

    public double getExcursionUptakeRate() {
        return this.excursionUptakeRate;
    }

    public BigDecimal getOnboardSpendAvg() {
        return this.onboardSpendAvg;
    }

    public long getTotalBookings() {
        return this.totalBookings;
    }

    public long getTotalPassengers() {
        return this.totalPassengers;
    }

    public void setVoyageId(Long voyageId) {
        this.voyageId = voyageId;
    }

    public void setOccupancyRate(double occupancyRate) {
        this.occupancyRate = occupancyRate;
    }

    public void setTotalRevenue(BigDecimal totalRevenue) {
        this.totalRevenue = totalRevenue;
    }

    public void setRevenuePerPassenger(BigDecimal revenuePerPassenger) {
        this.revenuePerPassenger = revenuePerPassenger;
    }

    public void setExcursionUptakeRate(double excursionUptakeRate) {
        this.excursionUptakeRate = excursionUptakeRate;
    }

    public void setOnboardSpendAvg(BigDecimal onboardSpendAvg) {
        this.onboardSpendAvg = onboardSpendAvg;
    }

    public void setTotalBookings(long totalBookings) {
        this.totalBookings = totalBookings;
    }

    public void setTotalPassengers(long totalPassengers) {
        this.totalPassengers = totalPassengers;
    }

    public static VoyageAnalyticsResponseBuilder builder() {
        return new VoyageAnalyticsResponseBuilder();
    }

    public static class VoyageAnalyticsResponseBuilder {
        private Long voyageId;
        private double occupancyRate;
        private BigDecimal totalRevenue;
        private BigDecimal revenuePerPassenger;
        private double excursionUptakeRate;
        private BigDecimal onboardSpendAvg;
        private long totalBookings;
        private long totalPassengers;

        public VoyageAnalyticsResponseBuilder voyageId(Long voyageId) {
            this.voyageId = voyageId;
            return this;
        }
        public VoyageAnalyticsResponseBuilder occupancyRate(double occupancyRate) {
            this.occupancyRate = occupancyRate;
            return this;
        }
        public VoyageAnalyticsResponseBuilder totalRevenue(BigDecimal totalRevenue) {
            this.totalRevenue = totalRevenue;
            return this;
        }
        public VoyageAnalyticsResponseBuilder revenuePerPassenger(BigDecimal revenuePerPassenger) {
            this.revenuePerPassenger = revenuePerPassenger;
            return this;
        }
        public VoyageAnalyticsResponseBuilder excursionUptakeRate(double excursionUptakeRate) {
            this.excursionUptakeRate = excursionUptakeRate;
            return this;
        }
        public VoyageAnalyticsResponseBuilder onboardSpendAvg(BigDecimal onboardSpendAvg) {
            this.onboardSpendAvg = onboardSpendAvg;
            return this;
        }
        public VoyageAnalyticsResponseBuilder totalBookings(long totalBookings) {
            this.totalBookings = totalBookings;
            return this;
        }
        public VoyageAnalyticsResponseBuilder totalPassengers(long totalPassengers) {
            this.totalPassengers = totalPassengers;
            return this;
        }

        public VoyageAnalyticsResponse build() {
            VoyageAnalyticsResponse instance = new VoyageAnalyticsResponse();
            instance.voyageId = this.voyageId;
            instance.occupancyRate = this.occupancyRate;
            instance.totalRevenue = this.totalRevenue;
            instance.revenuePerPassenger = this.revenuePerPassenger;
            instance.excursionUptakeRate = this.excursionUptakeRate;
            instance.onboardSpendAvg = this.onboardSpendAvg;
            instance.totalBookings = this.totalBookings;
            instance.totalPassengers = this.totalPassengers;
            return instance;
        }
    }

}
