package com.cruiseline.modules.excursion.repository;

import com.cruiseline.modules.excursion.entity.ExcursionManifest;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ExcursionManifestRepository extends JpaRepository<ExcursionManifest, Long> {
    List<ExcursionManifest> findByVoyageId(Long voyageId);
    boolean existsByExcursionIdAndVoyageId(Long excursionId, Long voyageId);
}