package com.cruiseline.modules.excursion.dto;

import com.cruiseline.common.enums.ExcursionBookingStatus;
import com.cruiseline.modules.excursion.entity.ExcursionBooking;

import java.math.BigDecimal;
import java.time.LocalDate;

public class ExcursionBookingResponse {
    private Long exBookingId;
    private Long excursionId;
    private Long passengerId;
    private Long voyageId;
    private LocalDate bookingDate;
    private BigDecimal price;
    private ExcursionBookingStatus status;

    public static ExcursionBookingResponse from(ExcursionBooking b) {
        return ExcursionBookingResponse.builder()
                .exBookingId(b.getExBookingId())
                .excursionId(b.getExcursionId())
                .passengerId(b.getPassengerId())
                .voyageId(b.getVoyageId())
                .bookingDate(b.getBookingDate())
                .price(b.getPrice())
                .status(b.getStatus())
                .build();
    }

    public ExcursionBookingResponse() {
    }

    public ExcursionBookingResponse(Long exBookingId, Long excursionId, Long passengerId, Long voyageId, LocalDate bookingDate, BigDecimal price, ExcursionBookingStatus status) {
        this.exBookingId = exBookingId;
        this.excursionId = excursionId;
        this.passengerId = passengerId;
        this.voyageId = voyageId;
        this.bookingDate = bookingDate;
        this.price = price;
        this.status = status;
    }

    public Long getExBookingId() {
        return this.exBookingId;
    }

    public Long getExcursionId() {
        return this.excursionId;
    }

    public Long getPassengerId() {
        return this.passengerId;
    }

    public Long getVoyageId() {
        return this.voyageId;
    }

    public LocalDate getBookingDate() {
        return this.bookingDate;
    }

    public BigDecimal getPrice() {
        return this.price;
    }

    public ExcursionBookingStatus getStatus() {
        return this.status;
    }

    public void setExBookingId(Long exBookingId) {
        this.exBookingId = exBookingId;
    }

    public void setExcursionId(Long excursionId) {
        this.excursionId = excursionId;
    }

    public void setPassengerId(Long passengerId) {
        this.passengerId = passengerId;
    }

    public void setVoyageId(Long voyageId) {
        this.voyageId = voyageId;
    }

    public void setBookingDate(LocalDate bookingDate) {
        this.bookingDate = bookingDate;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public void setStatus(ExcursionBookingStatus status) {
        this.status = status;
    }

    public static ExcursionBookingResponseBuilder builder() {
        return new ExcursionBookingResponseBuilder();
    }

    public static class ExcursionBookingResponseBuilder {
        private Long exBookingId;
        private Long excursionId;
        private Long passengerId;
        private Long voyageId;
        private LocalDate bookingDate;
        private BigDecimal price;
        private ExcursionBookingStatus status;

        public ExcursionBookingResponseBuilder exBookingId(Long exBookingId) {
            this.exBookingId = exBookingId;
            return this;
        }
        public ExcursionBookingResponseBuilder excursionId(Long excursionId) {
            this.excursionId = excursionId;
            return this;
        }
        public ExcursionBookingResponseBuilder passengerId(Long passengerId) {
            this.passengerId = passengerId;
            return this;
        }
        public ExcursionBookingResponseBuilder voyageId(Long voyageId) {
            this.voyageId = voyageId;
            return this;
        }
        public ExcursionBookingResponseBuilder bookingDate(LocalDate bookingDate) {
            this.bookingDate = bookingDate;
            return this;
        }
        public ExcursionBookingResponseBuilder price(BigDecimal price) {
            this.price = price;
            return this;
        }
        public ExcursionBookingResponseBuilder status(ExcursionBookingStatus status) {
            this.status = status;
            return this;
        }

        public ExcursionBookingResponse build() {
            ExcursionBookingResponse instance = new ExcursionBookingResponse();
            instance.exBookingId = this.exBookingId;
            instance.excursionId = this.excursionId;
            instance.passengerId = this.passengerId;
            instance.voyageId = this.voyageId;
            instance.bookingDate = this.bookingDate;
            instance.price = this.price;
            instance.status = this.status;
            return instance;
        }
    }

}
