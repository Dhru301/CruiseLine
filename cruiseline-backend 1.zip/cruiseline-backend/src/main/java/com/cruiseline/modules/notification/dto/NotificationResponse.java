package com.cruiseline.modules.notification.dto;

import com.cruiseline.common.enums.NotificationCategory;
import com.cruiseline.common.enums.NotificationStatus;
import com.cruiseline.modules.notification.entity.Notification;

import java.time.Instant;

public class NotificationResponse {
    private Long notificationId;
    private Long userId;
    private String message;
    private NotificationCategory category;
    private NotificationStatus status;
    private Instant createdDate;

    public static NotificationResponse from(Notification n) {
        return NotificationResponse.builder()
                .notificationId(n.getNotificationId())
                .userId(n.getUserId())
                .message(n.getMessage())
                .category(n.getCategory())
                .status(n.getStatus())
                .createdDate(n.getCreatedDate())
                .build();
    }

    public NotificationResponse() {
    }

    public NotificationResponse(Long notificationId, Long userId, String message, NotificationCategory category, NotificationStatus status, Instant createdDate) {
        this.notificationId = notificationId;
        this.userId = userId;
        this.message = message;
        this.category = category;
        this.status = status;
        this.createdDate = createdDate;
    }

    public Long getNotificationId() {
        return this.notificationId;
    }

    public Long getUserId() {
        return this.userId;
    }

    public String getMessage() {
        return this.message;
    }

    public NotificationCategory getCategory() {
        return this.category;
    }

    public NotificationStatus getStatus() {
        return this.status;
    }

    public Instant getCreatedDate() {
        return this.createdDate;
    }

    public void setNotificationId(Long notificationId) {
        this.notificationId = notificationId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setCategory(NotificationCategory category) {
        this.category = category;
    }

    public void setStatus(NotificationStatus status) {
        this.status = status;
    }

    public void setCreatedDate(Instant createdDate) {
        this.createdDate = createdDate;
    }

    public static NotificationResponseBuilder builder() {
        return new NotificationResponseBuilder();
    }

    public static class NotificationResponseBuilder {
        private Long notificationId;
        private Long userId;
        private String message;
        private NotificationCategory category;
        private NotificationStatus status;
        private Instant createdDate;

        public NotificationResponseBuilder notificationId(Long notificationId) {
            this.notificationId = notificationId;
            return this;
        }
        public NotificationResponseBuilder userId(Long userId) {
            this.userId = userId;
            return this;
        }
        public NotificationResponseBuilder message(String message) {
            this.message = message;
            return this;
        }
        public NotificationResponseBuilder category(NotificationCategory category) {
            this.category = category;
            return this;
        }
        public NotificationResponseBuilder status(NotificationStatus status) {
            this.status = status;
            return this;
        }
        public NotificationResponseBuilder createdDate(Instant createdDate) {
            this.createdDate = createdDate;
            return this;
        }

        public NotificationResponse build() {
            NotificationResponse instance = new NotificationResponse();
            instance.notificationId = this.notificationId;
            instance.userId = this.userId;
            instance.message = this.message;
            instance.category = this.category;
            instance.status = this.status;
            instance.createdDate = this.createdDate;
            return instance;
        }
    }

}
