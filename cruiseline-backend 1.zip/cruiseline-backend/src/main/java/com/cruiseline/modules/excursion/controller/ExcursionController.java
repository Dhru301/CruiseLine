package com.cruiseline.modules.excursion.controller;

import com.cruiseline.common.dto.ApiResponse;
import com.cruiseline.common.dto.PagedResponse;
import com.cruiseline.modules.excursion.dto.*;
import com.cruiseline.modules.excursion.service.ExcursionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "Shore Excursion", description = "Excursion catalog, bookings and port-day manifests")
@RestController
@RequestMapping("/api/excursions")
public class ExcursionController {

    private final ExcursionService excursionService;

    // ---- Catalog (browsing is open to all authenticated users) ----

    @Operation(summary = "List excursions (optional port filter)")
    @GetMapping
    public ApiResponse<PagedResponse<ExcursionResponse>> list(@RequestParam(required = false) String portOfCall,
                                                            Pageable pageable) {
        return ApiResponse.ok(excursionService.listExcursions(portOfCall, pageable));
    }

    @Operation(summary = "Get an excursion by id")
    @GetMapping("/{id}")
    public ApiResponse<ExcursionResponse> get(@PathVariable Long id) {
        return ApiResponse.ok(excursionService.getExcursion(id));
    }

    @Operation(summary = "Create an excursion (COORDINATOR/ADMIN)")
    @PostMapping
    @PreAuthorize("hasAnyRole('EXCURSION_COORDINATOR','ADMIN')")
    public ResponseEntity<ApiResponse<ExcursionResponse>> create(@Valid @RequestBody ExcursionRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Excursion created", excursionService.createExcursion(req)));
    }

    @Operation(summary = "Update an excursion (COORDINATOR/ADMIN)")
    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('EXCURSION_COORDINATOR','ADMIN')")
    public ApiResponse<ExcursionResponse> update(@PathVariable Long id, @Valid @RequestBody ExcursionRequest req) {
        return ApiResponse.ok("Excursion updated", excursionService.updateExcursion(id, req));
    }

    // ---- Bookings ----

    @Operation(summary = "Book an excursion (PASSENGER/COORDINATOR/ADMIN)")
    @PostMapping("/bookings")
    @PreAuthorize("hasAnyRole('PASSENGER','EXCURSION_COORDINATOR','ADMIN')")
    public ResponseEntity<ApiResponse<ExcursionBookingResponse>> book(@Valid @RequestBody ExcursionBookingRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Excursion booked", excursionService.book(req)));
    }

    @Operation(summary = "Cancel an excursion booking")
    @DeleteMapping("/bookings/{bookingId}")
    @PreAuthorize("hasAnyRole('PASSENGER','EXCURSION_COORDINATOR','ADMIN')")
    public ApiResponse<ExcursionBookingResponse> cancelBooking(@PathVariable Long bookingId) {
        return ApiResponse.ok("Booking cancelled", excursionService.cancelBooking(bookingId));
    }

    @Operation(summary = "List excursion bookings for a passenger")
    @GetMapping("/bookings/passenger/{passengerId}")
    public ApiResponse<PagedResponse<ExcursionBookingResponse>> passengerBookings(@PathVariable Long passengerId,
                                                                                Pageable pageable) {
        return ApiResponse.ok(excursionService.passengerBookings(passengerId, pageable));
    }

    // ---- Manifests ----

    @Operation(summary = "Generate a port-day manifest (COORDINATOR/ADMIN)")
    @PostMapping("/manifests")
    @PreAuthorize("hasAnyRole('EXCURSION_COORDINATOR','ADMIN')")
    public ResponseEntity<ApiResponse<ManifestResponse>> generateManifest(@Valid @RequestBody ManifestRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Manifest generated", excursionService.generateManifest(req)));
    }

    @Operation(summary = "Finalise a manifest (COORDINATOR/ADMIN)")
    @PatchMapping("/manifests/{manifestId}/finalise")
    @PreAuthorize("hasAnyRole('EXCURSION_COORDINATOR','ADMIN')")
    public ApiResponse<ManifestResponse> finalise(@PathVariable Long manifestId) {
        return ApiResponse.ok("Manifest finalised", excursionService.finaliseManifest(manifestId));
    }

    @Operation(summary = "List manifests for a voyage")
    @GetMapping("/manifests/voyage/{voyageId}")
    @PreAuthorize("hasAnyRole('EXCURSION_COORDINATOR','ADMIN')")
    public ApiResponse<List<ManifestResponse>> manifests(@PathVariable Long voyageId) {
        return ApiResponse.ok(excursionService.manifestsByVoyage(voyageId));
    }

    public ExcursionController(ExcursionService excursionService) {
        this.excursionService = excursionService;
    }

}
