package com.cruiseline.modules.account.service;

import com.cruiseline.common.audit.AuditService;
import com.cruiseline.common.enums.NotificationCategory;
import com.cruiseline.common.enums.AccountStatus;
import com.cruiseline.common.enums.ChargeStatus;
import com.cruiseline.common.enums.SettlementStatus;
import com.cruiseline.exception.BusinessRuleException;
import com.cruiseline.exception.DuplicateResourceException;
import com.cruiseline.exception.ResourceNotFoundException;
import com.cruiseline.modules.account.dto.*;
import com.cruiseline.modules.account.entity.FolioSettlement;
import com.cruiseline.modules.account.entity.OnboardAccount;
import com.cruiseline.modules.account.entity.OnboardCharge;
import com.cruiseline.modules.account.repository.FolioSettlementRepository;
import com.cruiseline.modules.account.repository.OnboardAccountRepository;
import com.cruiseline.modules.account.repository.OnboardChargeRepository;
import com.cruiseline.modules.notification.service.NotificationService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
public class AccountService {

    private final OnboardAccountRepository accountRepository;
    private final OnboardChargeRepository chargeRepository;
    private final FolioSettlementRepository settlementRepository;
    private final AuditService auditService;
    private final NotificationService notificationService;

    @Transactional
    public AccountResponse openAccount(CreateAccountRequest req) {
        accountRepository.findByPassengerIdAndVoyageId(req.getPassengerId(), req.getVoyageId())
                .ifPresent(a -> { throw new DuplicateResourceException("An onboard account already exists for this passenger on this voyage"); });
        OnboardAccount account = OnboardAccount.builder()
                .passengerId(req.getPassengerId())
                .voyageId(req.getVoyageId())
                .creditLimit(req.getCreditLimit())
                .currentBalance(BigDecimal.ZERO)
                .status(AccountStatus.ACTIVE)
                .build();
        auditService.record("ONBOARD_ACCOUNT_OPENED", "OnboardAccount");
        return AccountResponse.from(accountRepository.save(account));
    }

    @Transactional(readOnly = true)
    public AccountResponse getAccount(Long id) {
        return AccountResponse.from(findAccount(id));
    }

    @Transactional
    public ChargeResponse postCharge(Long postedById, ChargeRequest req) {
        OnboardAccount account = findAccount(req.getAccountId());
        if (account.getStatus() != AccountStatus.ACTIVE) {
            throw new BusinessRuleException("Cannot post a charge to a non-active account");
        }
        BigDecimal projected = account.getCurrentBalance().add(req.getAmount());
        if (projected.compareTo(account.getCreditLimit()) > 0) {
            throw new BusinessRuleException("Charge exceeds the account credit limit");
        }
        OnboardCharge charge = OnboardCharge.builder()
                .accountId(account.getAccountId())
                .chargeType(req.getChargeType())
                .description(req.getDescription())
                .amount(req.getAmount())
                .postedById(postedById)
                .status(ChargeStatus.POSTED)
                .build();
        charge = chargeRepository.save(charge);

        account.setCurrentBalance(projected);
        auditService.record("CHARGE_POSTED", "OnboardCharge");
        notificationService.notify(account.getPassengerId(),
            "A " + req.getChargeType() + " charge of $" + req.getAmount()
                + " was posted to your folio. Current balance $" + account.getCurrentBalance() + ".",
            NotificationCategory.ACCOUNT);
        return ChargeResponse.from(charge);
    }

    @Transactional
    public ChargeResponse reverseCharge(Long chargeId) {
        OnboardCharge charge = chargeRepository.findById(chargeId)
                .orElseThrow(() -> new ResourceNotFoundException("OnboardCharge", "id", chargeId));
        if (charge.getStatus() == ChargeStatus.REVERSED) {
            throw new BusinessRuleException("Charge is already reversed");
        }
        OnboardAccount account = findAccount(charge.getAccountId());
        if (account.getStatus() != AccountStatus.ACTIVE) {
            throw new BusinessRuleException(
                "Cannot reverse a charge on a " + account.getStatus() + " account; the folio is closed");
        }
        charge.setStatus(ChargeStatus.REVERSED);
        account.setCurrentBalance(account.getCurrentBalance().subtract(charge.getAmount()));
        auditService.record("CHARGE_REVERSED", "OnboardCharge");
        return ChargeResponse.from(charge);
    }

    @Transactional(readOnly = true)
    public List<ChargeResponse> listCharges(Long accountId) {
        return chargeRepository.findByAccountId(accountId).stream()
                .map(ChargeResponse::from).toList();
    }

    @Transactional
    public SettlementResponse settle(SettlementRequest req) {
        OnboardAccount account = findAccount(req.getAccountId());
        if (account.getStatus() != AccountStatus.ACTIVE) {
            throw new BusinessRuleException(
                "Account is already " + account.getStatus() + "; it cannot be settled again");
        }

        List<OnboardCharge> charges = chargeRepository.findByAccountId(account.getAccountId());
        BigDecimal totalCharges = charges.stream()
                .filter(c -> c.getStatus() == ChargeStatus.POSTED)
                .map(OnboardCharge::getAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal balance = account.getCurrentBalance();

        FolioSettlement settlement = FolioSettlement.builder()
                .accountId(account.getAccountId())
                .totalCharges(totalCharges)
                .totalCredits(BigDecimal.ZERO)
                .balanceSettled(balance)
                .paymentMode(req.getPaymentMode())
                .status(balance.compareTo(BigDecimal.ZERO) < 0 ? SettlementStatus.REFUNDED : SettlementStatus.SETTLED)
                .build();
        settlement = settlementRepository.save(settlement);

        account.setCurrentBalance(BigDecimal.ZERO);
        account.setStatus(AccountStatus.SETTLED);
        auditService.record("FOLIO_SETTLED", "FolioSettlement");
        notificationService.notify(account.getPassengerId(),
            "Your onboard folio has been settled (" + settlement.getStatus() + ", $"
                + settlement.getBalanceSettled() + " via " + settlement.getPaymentMode() + ").",
            NotificationCategory.ACCOUNT);
        return SettlementResponse.from(settlement);
    }

    private OnboardAccount findAccount(Long id) {
        return accountRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("OnboardAccount", "id", id));
    }

    public AccountService(OnboardAccountRepository accountRepository, OnboardChargeRepository chargeRepository, FolioSettlementRepository settlementRepository, AuditService auditService, NotificationService notificationService) {
        this.accountRepository = accountRepository;
        this.chargeRepository = chargeRepository;
        this.settlementRepository = settlementRepository;
        this.auditService = auditService;
        this.notificationService = notificationService;
    }

}