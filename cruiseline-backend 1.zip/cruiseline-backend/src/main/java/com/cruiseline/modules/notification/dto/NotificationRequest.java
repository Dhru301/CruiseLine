package com.cruiseline.modules.notification.dto;

import com.cruiseline.common.enums.NotificationCategory;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class NotificationRequest {
    @NotNull
    private Long userId;
    @NotBlank
    private String message;
    @NotNull
    private NotificationCategory category;

    public Long getUserId() {
        return this.userId;
    }

    public String getMessage() {
        return this.message;
    }

    public NotificationCategory getCategory() {
        return this.category;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setCategory(NotificationCategory category) {
        this.category = category;
    }

}
