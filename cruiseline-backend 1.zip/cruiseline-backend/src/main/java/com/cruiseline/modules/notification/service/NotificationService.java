package com.cruiseline.modules.notification.service;

import com.cruiseline.common.dto.PagedResponse;
import com.cruiseline.common.enums.NotificationCategory;
import com.cruiseline.common.enums.NotificationStatus;
import com.cruiseline.exception.ResourceNotFoundException;
import com.cruiseline.modules.notification.dto.NotificationRequest;
import com.cruiseline.modules.notification.dto.NotificationResponse;
import com.cruiseline.modules.notification.entity.Notification;
import com.cruiseline.modules.notification.repository.NotificationRepository;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
public class NotificationService {

    private final NotificationRepository notificationRepository;

    /**
     * Creates an in-app notification. Other modules can call this directly
     * (e.g. on booking confirmation, balance-due reminders, drill alerts).
     */
    @Transactional
    public NotificationResponse create(NotificationRequest req) {
        Notification n = Notification.builder()
                .userId(req.getUserId())
                .message(req.getMessage())
                .category(req.getCategory())
                .status(NotificationStatus.UNREAD)
                .build();
        return NotificationResponse.from(notificationRepository.save(n));
    }

    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(NotificationService.class);

    /**
     * Convenience method for internal use by other services (event-triggered
     * alerts). Runs in its OWN transaction and never propagates failures, so a
     * notification problem can never roll back the business operation that
     * triggered it.
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void notify(Long userId, String message, NotificationCategory category) {
        if (userId == null) return;
        try {
            notificationRepository.save(Notification.builder()
                    .userId(userId).message(message).category(category)
                    .status(NotificationStatus.UNREAD).build());
        } catch (RuntimeException ex) {
            log.warn("Failed to create notification for user {}: {}", userId, ex.getMessage());
        }
    }

    @Transactional(readOnly = true)
    public PagedResponse<NotificationResponse> list(Long userId, NotificationStatus status, Pageable pageable) {
        var page = (status == null)
                ? notificationRepository.findByUserId(userId, pageable).map(NotificationResponse::from)
                : notificationRepository.findByUserIdAndStatus(userId, status, pageable).map(NotificationResponse::from);
        return PagedResponse.from(page);
    }

    @Transactional(readOnly = true)
    public long unreadCount(Long userId) {
        return notificationRepository.countByUserIdAndStatus(userId, NotificationStatus.UNREAD);
    }

    @Transactional
    public NotificationResponse markRead(Long id, Long userId) {
        Notification n = findOwned(id, userId);
        n.setStatus(NotificationStatus.READ);
        return NotificationResponse.from(n);
    }

    @Transactional
    public NotificationResponse dismiss(Long id, Long userId) {
        Notification n = findOwned(id, userId);
        n.setStatus(NotificationStatus.DISMISSED);
        return NotificationResponse.from(n);
    }

    private Notification findOwned(Long id, Long userId) {
        Notification n = notificationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Notification", "id", id));
        if (!n.getUserId().equals(userId)) {
            throw new ResourceNotFoundException("Notification", "id", id);
        }
        return n;
    }

    public NotificationService(NotificationRepository notificationRepository) {
        this.notificationRepository = notificationRepository;
    }

}