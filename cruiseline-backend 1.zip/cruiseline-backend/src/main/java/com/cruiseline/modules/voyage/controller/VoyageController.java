package com.cruiseline.modules.voyage.controller;

import com.cruiseline.common.dto.ApiResponse;
import com.cruiseline.common.dto.PagedResponse;
import com.cruiseline.common.enums.VoyageStatus;
import com.cruiseline.modules.voyage.dto.*;
import com.cruiseline.modules.voyage.service.VoyageService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "Voyage & Cabin Inventory", description = "Voyage itineraries, cabin categories and cabins")
@RestController
@RequestMapping("/api/voyages")
public class VoyageController {

    private final VoyageService voyageService;

    // ---- Voyages ----

    @Operation(summary = "List voyages (any authenticated user). Optional status filter.")
    @GetMapping
    public ApiResponse<PagedResponse<VoyageResponse>> list(@RequestParam(required = false) VoyageStatus status,
                                                          Pageable pageable) {
        return ApiResponse.ok(voyageService.listVoyages(status, pageable));
    }

    @Operation(summary = "Get a voyage by id")
    @GetMapping("/{id}")
    public ApiResponse<VoyageResponse> get(@PathVariable Long id) {
        return ApiResponse.ok(voyageService.getVoyage(id));
    }

    @Operation(summary = "Create a voyage (ADMIN only)")
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<VoyageResponse>> create(@Valid @RequestBody VoyageRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Voyage created", voyageService.createVoyage(req)));
    }

    @Operation(summary = "Update a voyage (ADMIN only)")
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ApiResponse<VoyageResponse> update(@PathVariable Long id, @Valid @RequestBody VoyageRequest req) {
        return ApiResponse.ok("Voyage updated", voyageService.updateVoyage(id, req));
    }

    @Operation(summary = "Change voyage status (ADMIN only)")
    @PatchMapping("/{id}/status")
    @PreAuthorize("hasRole('ADMIN')")
    public ApiResponse<VoyageResponse> updateStatus(@PathVariable Long id,
                                                   @Valid @RequestBody UpdateVoyageStatusRequest req) {
        return ApiResponse.ok("Status updated", voyageService.updateStatus(id, req));
    }

    // ---- Cabin categories ----

    @Operation(summary = "List cabin categories for a voyage")
    @GetMapping("/{voyageId}/categories")
    public ApiResponse<List<CabinCategoryResponse>> categories(@PathVariable Long voyageId) {
        return ApiResponse.ok(voyageService.listCategories(voyageId));
    }

    @Operation(summary = "Add a cabin category (ADMIN only)")
    @PostMapping("/categories")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<CabinCategoryResponse>> addCategory(@Valid @RequestBody CabinCategoryRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Category created", voyageService.addCategory(req)));
    }

    // ---- Cabins ----

    @Operation(summary = "List cabins in a category")
    @GetMapping("/categories/{categoryId}/cabins")
    public ApiResponse<List<CabinResponse>> cabins(@PathVariable Long categoryId) {
        return ApiResponse.ok(voyageService.listCabins(categoryId));
    }

    @Operation(summary = "Add a cabin (ADMIN only)")
    @PostMapping("/cabins")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<CabinResponse>> addCabin(@Valid @RequestBody CabinRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Cabin created", voyageService.addCabin(req)));
    }

    public VoyageController(VoyageService voyageService) {
        this.voyageService = voyageService;
    }

}
