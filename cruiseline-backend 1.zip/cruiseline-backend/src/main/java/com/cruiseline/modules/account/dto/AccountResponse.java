package com.cruiseline.modules.account.dto;

import com.cruiseline.common.enums.AccountStatus;
import com.cruiseline.modules.account.entity.OnboardAccount;

import java.math.BigDecimal;

public class AccountResponse {
    private Long accountId;
    private Long passengerId;
    private Long voyageId;
    private BigDecimal creditLimit;
    private BigDecimal currentBalance;
    private AccountStatus status;

    public static AccountResponse from(OnboardAccount a) {
        return AccountResponse.builder()
                .accountId(a.getAccountId())
                .passengerId(a.getPassengerId())
                .voyageId(a.getVoyageId())
                .creditLimit(a.getCreditLimit())
                .currentBalance(a.getCurrentBalance())
                .status(a.getStatus())
                .build();
    }

    public AccountResponse() {
    }

    public AccountResponse(Long accountId, Long passengerId, Long voyageId, BigDecimal creditLimit, BigDecimal currentBalance, AccountStatus status) {
        this.accountId = accountId;
        this.passengerId = passengerId;
        this.voyageId = voyageId;
        this.creditLimit = creditLimit;
        this.currentBalance = currentBalance;
        this.status = status;
    }

    public Long getAccountId() {
        return this.accountId;
    }

    public Long getPassengerId() {
        return this.passengerId;
    }

    public Long getVoyageId() {
        return this.voyageId;
    }

    public BigDecimal getCreditLimit() {
        return this.creditLimit;
    }

    public BigDecimal getCurrentBalance() {
        return this.currentBalance;
    }

    public AccountStatus getStatus() {
        return this.status;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public void setPassengerId(Long passengerId) {
        this.passengerId = passengerId;
    }

    public void setVoyageId(Long voyageId) {
        this.voyageId = voyageId;
    }

    public void setCreditLimit(BigDecimal creditLimit) {
        this.creditLimit = creditLimit;
    }

    public void setCurrentBalance(BigDecimal currentBalance) {
        this.currentBalance = currentBalance;
    }

    public void setStatus(AccountStatus status) {
        this.status = status;
    }

    public static AccountResponseBuilder builder() {
        return new AccountResponseBuilder();
    }

    public static class AccountResponseBuilder {
        private Long accountId;
        private Long passengerId;
        private Long voyageId;
        private BigDecimal creditLimit;
        private BigDecimal currentBalance;
        private AccountStatus status;

        public AccountResponseBuilder accountId(Long accountId) {
            this.accountId = accountId;
            return this;
        }
        public AccountResponseBuilder passengerId(Long passengerId) {
            this.passengerId = passengerId;
            return this;
        }
        public AccountResponseBuilder voyageId(Long voyageId) {
            this.voyageId = voyageId;
            return this;
        }
        public AccountResponseBuilder creditLimit(BigDecimal creditLimit) {
            this.creditLimit = creditLimit;
            return this;
        }
        public AccountResponseBuilder currentBalance(BigDecimal currentBalance) {
            this.currentBalance = currentBalance;
            return this;
        }
        public AccountResponseBuilder status(AccountStatus status) {
            this.status = status;
            return this;
        }

        public AccountResponse build() {
            AccountResponse instance = new AccountResponse();
            instance.accountId = this.accountId;
            instance.passengerId = this.passengerId;
            instance.voyageId = this.voyageId;
            instance.creditLimit = this.creditLimit;
            instance.currentBalance = this.currentBalance;
            instance.status = this.status;
            return instance;
        }
    }

}
