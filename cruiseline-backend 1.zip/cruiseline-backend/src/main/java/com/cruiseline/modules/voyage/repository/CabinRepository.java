package com.cruiseline.modules.voyage.repository;

import com.cruiseline.common.enums.CabinStatus;
import com.cruiseline.modules.voyage.entity.Cabin;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CabinRepository extends JpaRepository<Cabin, Long> {
    List<Cabin> findByCategoryCategoryId(Long categoryId);
    List<Cabin> findByCategoryCategoryIdAndStatus(Long categoryId, CabinStatus status);
}
