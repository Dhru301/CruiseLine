package com.cruiseline.modules.account.dto;

import com.cruiseline.common.enums.ChargeType;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

public class ChargeRequest {
    @NotNull
    private Long accountId;
    @NotNull
    private ChargeType chargeType;
    private String description;
    @NotNull @DecimalMin("0.01")
    private BigDecimal amount;

    public Long getAccountId() {
        return this.accountId;
    }

    public ChargeType getChargeType() {
        return this.chargeType;
    }

    public String getDescription() {
        return this.description;
    }

    public BigDecimal getAmount() {
        return this.amount;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public void setChargeType(ChargeType chargeType) {
        this.chargeType = chargeType;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

}
