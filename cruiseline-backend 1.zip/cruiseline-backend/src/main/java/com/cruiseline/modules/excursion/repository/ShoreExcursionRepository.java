package com.cruiseline.modules.excursion.repository;

import com.cruiseline.modules.excursion.entity.ShoreExcursion;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ShoreExcursionRepository extends JpaRepository<ShoreExcursion, Long> {
    Page<ShoreExcursion> findByPortOfCall(String portOfCall, Pageable pageable);
}
