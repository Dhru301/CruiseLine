package com.cruiseline.modules.account.repository;

import com.cruiseline.modules.account.entity.OnboardCharge;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OnboardChargeRepository extends JpaRepository<OnboardCharge, Long> {
    List<OnboardCharge> findByAccountId(Long accountId);
}
