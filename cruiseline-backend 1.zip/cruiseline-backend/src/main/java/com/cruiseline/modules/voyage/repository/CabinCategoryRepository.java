package com.cruiseline.modules.voyage.repository;

import com.cruiseline.modules.voyage.entity.CabinCategory;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CabinCategoryRepository extends JpaRepository<CabinCategory, Long> {
    List<CabinCategory> findByVoyageVoyageId(Long voyageId);
}
