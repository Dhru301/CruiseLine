package com.cruiseline.modules.voyage.dto;

import com.cruiseline.common.enums.VoyageStatus;
import com.cruiseline.modules.voyage.entity.Voyage;

import java.time.LocalDate;

public class VoyageResponse {
    private Long voyageId;
    private String voyageName;
    private String vesselId;
    private String homePort;
    private LocalDate departureDate;
    private LocalDate returnDate;
    private Integer durationNights;
    private String portsOfCall;
    private VoyageStatus status;

    public static VoyageResponse from(Voyage v) {
        return VoyageResponse.builder()
                .voyageId(v.getVoyageId())
                .voyageName(v.getVoyageName())
                .vesselId(v.getVesselId())
                .homePort(v.getHomePort())
                .departureDate(v.getDepartureDate())
                .returnDate(v.getReturnDate())
                .durationNights(v.getDurationNights())
                .portsOfCall(v.getPortsOfCall())
                .status(v.getStatus())
                .build();
    }

    public VoyageResponse() {
    }

    public VoyageResponse(Long voyageId, String voyageName, String vesselId, String homePort, LocalDate departureDate, LocalDate returnDate, Integer durationNights, String portsOfCall, VoyageStatus status) {
        this.voyageId = voyageId;
        this.voyageName = voyageName;
        this.vesselId = vesselId;
        this.homePort = homePort;
        this.departureDate = departureDate;
        this.returnDate = returnDate;
        this.durationNights = durationNights;
        this.portsOfCall = portsOfCall;
        this.status = status;
    }

    public Long getVoyageId() {
        return this.voyageId;
    }

    public String getVoyageName() {
        return this.voyageName;
    }

    public String getVesselId() {
        return this.vesselId;
    }

    public String getHomePort() {
        return this.homePort;
    }

    public LocalDate getDepartureDate() {
        return this.departureDate;
    }

    public LocalDate getReturnDate() {
        return this.returnDate;
    }

    public Integer getDurationNights() {
        return this.durationNights;
    }

    public String getPortsOfCall() {
        return this.portsOfCall;
    }

    public VoyageStatus getStatus() {
        return this.status;
    }

    public void setVoyageId(Long voyageId) {
        this.voyageId = voyageId;
    }

    public void setVoyageName(String voyageName) {
        this.voyageName = voyageName;
    }

    public void setVesselId(String vesselId) {
        this.vesselId = vesselId;
    }

    public void setHomePort(String homePort) {
        this.homePort = homePort;
    }

    public void setDepartureDate(LocalDate departureDate) {
        this.departureDate = departureDate;
    }

    public void setReturnDate(LocalDate returnDate) {
        this.returnDate = returnDate;
    }

    public void setDurationNights(Integer durationNights) {
        this.durationNights = durationNights;
    }

    public void setPortsOfCall(String portsOfCall) {
        this.portsOfCall = portsOfCall;
    }

    public void setStatus(VoyageStatus status) {
        this.status = status;
    }

    public static VoyageResponseBuilder builder() {
        return new VoyageResponseBuilder();
    }

    public static class VoyageResponseBuilder {
        private Long voyageId;
        private String voyageName;
        private String vesselId;
        private String homePort;
        private LocalDate departureDate;
        private LocalDate returnDate;
        private Integer durationNights;
        private String portsOfCall;
        private VoyageStatus status;

        public VoyageResponseBuilder voyageId(Long voyageId) {
            this.voyageId = voyageId;
            return this;
        }
        public VoyageResponseBuilder voyageName(String voyageName) {
            this.voyageName = voyageName;
            return this;
        }
        public VoyageResponseBuilder vesselId(String vesselId) {
            this.vesselId = vesselId;
            return this;
        }
        public VoyageResponseBuilder homePort(String homePort) {
            this.homePort = homePort;
            return this;
        }
        public VoyageResponseBuilder departureDate(LocalDate departureDate) {
            this.departureDate = departureDate;
            return this;
        }
        public VoyageResponseBuilder returnDate(LocalDate returnDate) {
            this.returnDate = returnDate;
            return this;
        }
        public VoyageResponseBuilder durationNights(Integer durationNights) {
            this.durationNights = durationNights;
            return this;
        }
        public VoyageResponseBuilder portsOfCall(String portsOfCall) {
            this.portsOfCall = portsOfCall;
            return this;
        }
        public VoyageResponseBuilder status(VoyageStatus status) {
            this.status = status;
            return this;
        }

        public VoyageResponse build() {
            VoyageResponse instance = new VoyageResponse();
            instance.voyageId = this.voyageId;
            instance.voyageName = this.voyageName;
            instance.vesselId = this.vesselId;
            instance.homePort = this.homePort;
            instance.departureDate = this.departureDate;
            instance.returnDate = this.returnDate;
            instance.durationNights = this.durationNights;
            instance.portsOfCall = this.portsOfCall;
            instance.status = this.status;
            return instance;
        }
    }

}
