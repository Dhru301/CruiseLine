package com.cruiseline.modules.excursion.dto;

import com.cruiseline.common.enums.DifficultyLevel;
import com.cruiseline.common.enums.ExcursionCategory;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;

public class ExcursionRequest {
    @NotBlank
    private String portOfCall;
    @NotBlank
    private String excursionName;
    private ExcursionCategory category;
    @Positive
    private Double durationHours;
    @NotNull @DecimalMin("0.0")
    private BigDecimal price;
    @NotNull @Min(1)
    private Integer maxCapacity;
    private DifficultyLevel difficultyLevel;

    public String getPortOfCall() {
        return this.portOfCall;
    }

    public String getExcursionName() {
        return this.excursionName;
    }

    public ExcursionCategory getCategory() {
        return this.category;
    }

    public Double getDurationHours() {
        return this.durationHours;
    }

    public BigDecimal getPrice() {
        return this.price;
    }

    public Integer getMaxCapacity() {
        return this.maxCapacity;
    }

    public DifficultyLevel getDifficultyLevel() {
        return this.difficultyLevel;
    }

    public void setPortOfCall(String portOfCall) {
        this.portOfCall = portOfCall;
    }

    public void setExcursionName(String excursionName) {
        this.excursionName = excursionName;
    }

    public void setCategory(ExcursionCategory category) {
        this.category = category;
    }

    public void setDurationHours(Double durationHours) {
        this.durationHours = durationHours;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public void setMaxCapacity(Integer maxCapacity) {
        this.maxCapacity = maxCapacity;
    }

    public void setDifficultyLevel(DifficultyLevel difficultyLevel) {
        this.difficultyLevel = difficultyLevel;
    }

}
