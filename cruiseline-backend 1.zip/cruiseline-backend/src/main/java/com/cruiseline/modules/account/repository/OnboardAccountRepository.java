package com.cruiseline.modules.account.repository;

import com.cruiseline.modules.account.entity.OnboardAccount;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface OnboardAccountRepository extends JpaRepository<OnboardAccount, Long> {
    Optional<OnboardAccount> findByPassengerIdAndVoyageId(Long passengerId, Long voyageId);
    List<OnboardAccount> findByVoyageId(Long voyageId);
}