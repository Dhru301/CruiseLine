package com.cruiseline.modules.auth.dto;

import com.cruiseline.common.enums.Role;
import jakarta.validation.constraints.*;

public class RegisterRequest {
    @NotBlank @Size(max = 120)
    private String name;

    @NotBlank @Email
    private String email;

    @NotBlank @Size(min = 8, max = 100)
    private String password;

    @Size(max = 30)
    private String phone;

    // Optional; defaults to PASSENGER for public self-registration.
    private Role role;

    private String vesselId;

    public String getName() {
        return this.name;
    }

    public String getEmail() {
        return this.email;
    }

    public String getPassword() {
        return this.password;
    }

    public String getPhone() {
        return this.phone;
    }

    public Role getRole() {
        return this.role;
    }

    public String getVesselId() {
        return this.vesselId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public void setVesselId(String vesselId) {
        this.vesselId = vesselId;
    }

}
