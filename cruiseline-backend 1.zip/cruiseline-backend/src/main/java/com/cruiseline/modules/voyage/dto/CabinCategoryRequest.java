package com.cruiseline.modules.voyage.dto;

import com.cruiseline.common.enums.CabinCategoryName;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;

public class CabinCategoryRequest {
    @NotNull
    private Long voyageId;

    @NotNull
    private CabinCategoryName categoryName;

    private String deck;
    private String beddingConfig;

    @NotNull @Min(1)
    private Integer maxOccupancy;

    @NotNull @DecimalMin("0.0")
    private BigDecimal basePrice;

    @NotNull @Min(0)
    private Integer totalCabins;

    public Long getVoyageId() {
        return this.voyageId;
    }

    public CabinCategoryName getCategoryName() {
        return this.categoryName;
    }

    public String getDeck() {
        return this.deck;
    }

    public String getBeddingConfig() {
        return this.beddingConfig;
    }

    public Integer getMaxOccupancy() {
        return this.maxOccupancy;
    }

    public BigDecimal getBasePrice() {
        return this.basePrice;
    }

    public Integer getTotalCabins() {
        return this.totalCabins;
    }

    public void setVoyageId(Long voyageId) {
        this.voyageId = voyageId;
    }

    public void setCategoryName(CabinCategoryName categoryName) {
        this.categoryName = categoryName;
    }

    public void setDeck(String deck) {
        this.deck = deck;
    }

    public void setBeddingConfig(String beddingConfig) {
        this.beddingConfig = beddingConfig;
    }

    public void setMaxOccupancy(Integer maxOccupancy) {
        this.maxOccupancy = maxOccupancy;
    }

    public void setBasePrice(BigDecimal basePrice) {
        this.basePrice = basePrice;
    }

    public void setTotalCabins(Integer totalCabins) {
        this.totalCabins = totalCabins;
    }

}
