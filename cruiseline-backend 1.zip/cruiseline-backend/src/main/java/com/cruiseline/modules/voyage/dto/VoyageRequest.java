package com.cruiseline.modules.voyage.dto;

import com.cruiseline.common.enums.VoyageStatus;
import jakarta.validation.constraints.*;

import java.time.LocalDate;

public class VoyageRequest {
    @NotBlank @Size(max = 150)
    private String voyageName;

    @NotBlank
    private String vesselId;

    @NotBlank
    private String homePort;

    @NotNull @FutureOrPresent
    private LocalDate departureDate;

    @NotNull
    private LocalDate returnDate;

    @NotNull @Min(1)
    private Integer durationNights;

    private String portsOfCall;

    private VoyageStatus status;

    public String getVoyageName() {
        return this.voyageName;
    }

    public String getVesselId() {
        return this.vesselId;
    }

    public String getHomePort() {
        return this.homePort;
    }

    public LocalDate getDepartureDate() {
        return this.departureDate;
    }

    public LocalDate getReturnDate() {
        return this.returnDate;
    }

    public Integer getDurationNights() {
        return this.durationNights;
    }

    public String getPortsOfCall() {
        return this.portsOfCall;
    }

    public VoyageStatus getStatus() {
        return this.status;
    }

    public void setVoyageName(String voyageName) {
        this.voyageName = voyageName;
    }

    public void setVesselId(String vesselId) {
        this.vesselId = vesselId;
    }

    public void setHomePort(String homePort) {
        this.homePort = homePort;
    }

    public void setDepartureDate(LocalDate departureDate) {
        this.departureDate = departureDate;
    }

    public void setReturnDate(LocalDate returnDate) {
        this.returnDate = returnDate;
    }

    public void setDurationNights(Integer durationNights) {
        this.durationNights = durationNights;
    }

    public void setPortsOfCall(String portsOfCall) {
        this.portsOfCall = portsOfCall;
    }

    public void setStatus(VoyageStatus status) {
        this.status = status;
    }

}
