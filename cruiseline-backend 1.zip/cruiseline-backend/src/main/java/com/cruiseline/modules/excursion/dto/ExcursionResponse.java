package com.cruiseline.modules.excursion.dto;

import com.cruiseline.common.enums.DifficultyLevel;
import com.cruiseline.common.enums.ExcursionCategory;
import com.cruiseline.common.enums.ExcursionStatus;
import com.cruiseline.modules.excursion.entity.ShoreExcursion;

import java.math.BigDecimal;

public class ExcursionResponse {
    private Long excursionId;
    private String portOfCall;
    private String excursionName;
    private ExcursionCategory category;
    private Double durationHours;
    private BigDecimal price;
    private Integer maxCapacity;
    private Integer bookedCount;
    private DifficultyLevel difficultyLevel;
    private ExcursionStatus status;

    public static ExcursionResponse from(ShoreExcursion e) {
        return ExcursionResponse.builder()
                .excursionId(e.getExcursionId())
                .portOfCall(e.getPortOfCall())
                .excursionName(e.getExcursionName())
                .category(e.getCategory())
                .durationHours(e.getDurationHours())
                .price(e.getPrice())
                .maxCapacity(e.getMaxCapacity())
                .bookedCount(e.getBookedCount())
                .difficultyLevel(e.getDifficultyLevel())
                .status(e.getStatus())
                .build();
    }

    public ExcursionResponse() {
    }

    public ExcursionResponse(Long excursionId, String portOfCall, String excursionName, ExcursionCategory category, Double durationHours, BigDecimal price, Integer maxCapacity, Integer bookedCount, DifficultyLevel difficultyLevel, ExcursionStatus status) {
        this.excursionId = excursionId;
        this.portOfCall = portOfCall;
        this.excursionName = excursionName;
        this.category = category;
        this.durationHours = durationHours;
        this.price = price;
        this.maxCapacity = maxCapacity;
        this.bookedCount = bookedCount;
        this.difficultyLevel = difficultyLevel;
        this.status = status;
    }

    public Long getExcursionId() {
        return this.excursionId;
    }

    public String getPortOfCall() {
        return this.portOfCall;
    }

    public String getExcursionName() {
        return this.excursionName;
    }

    public ExcursionCategory getCategory() {
        return this.category;
    }

    public Double getDurationHours() {
        return this.durationHours;
    }

    public BigDecimal getPrice() {
        return this.price;
    }

    public Integer getMaxCapacity() {
        return this.maxCapacity;
    }

    public Integer getBookedCount() {
        return this.bookedCount;
    }

    public DifficultyLevel getDifficultyLevel() {
        return this.difficultyLevel;
    }

    public ExcursionStatus getStatus() {
        return this.status;
    }

    public void setExcursionId(Long excursionId) {
        this.excursionId = excursionId;
    }

    public void setPortOfCall(String portOfCall) {
        this.portOfCall = portOfCall;
    }

    public void setExcursionName(String excursionName) {
        this.excursionName = excursionName;
    }

    public void setCategory(ExcursionCategory category) {
        this.category = category;
    }

    public void setDurationHours(Double durationHours) {
        this.durationHours = durationHours;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public void setMaxCapacity(Integer maxCapacity) {
        this.maxCapacity = maxCapacity;
    }

    public void setBookedCount(Integer bookedCount) {
        this.bookedCount = bookedCount;
    }

    public void setDifficultyLevel(DifficultyLevel difficultyLevel) {
        this.difficultyLevel = difficultyLevel;
    }

    public void setStatus(ExcursionStatus status) {
        this.status = status;
    }

    public static ExcursionResponseBuilder builder() {
        return new ExcursionResponseBuilder();
    }

    public static class ExcursionResponseBuilder {
        private Long excursionId;
        private String portOfCall;
        private String excursionName;
        private ExcursionCategory category;
        private Double durationHours;
        private BigDecimal price;
        private Integer maxCapacity;
        private Integer bookedCount;
        private DifficultyLevel difficultyLevel;
        private ExcursionStatus status;

        public ExcursionResponseBuilder excursionId(Long excursionId) {
            this.excursionId = excursionId;
            return this;
        }
        public ExcursionResponseBuilder portOfCall(String portOfCall) {
            this.portOfCall = portOfCall;
            return this;
        }
        public ExcursionResponseBuilder excursionName(String excursionName) {
            this.excursionName = excursionName;
            return this;
        }
        public ExcursionResponseBuilder category(ExcursionCategory category) {
            this.category = category;
            return this;
        }
        public ExcursionResponseBuilder durationHours(Double durationHours) {
            this.durationHours = durationHours;
            return this;
        }
        public ExcursionResponseBuilder price(BigDecimal price) {
            this.price = price;
            return this;
        }
        public ExcursionResponseBuilder maxCapacity(Integer maxCapacity) {
            this.maxCapacity = maxCapacity;
            return this;
        }
        public ExcursionResponseBuilder bookedCount(Integer bookedCount) {
            this.bookedCount = bookedCount;
            return this;
        }
        public ExcursionResponseBuilder difficultyLevel(DifficultyLevel difficultyLevel) {
            this.difficultyLevel = difficultyLevel;
            return this;
        }
        public ExcursionResponseBuilder status(ExcursionStatus status) {
            this.status = status;
            return this;
        }

        public ExcursionResponse build() {
            ExcursionResponse instance = new ExcursionResponse();
            instance.excursionId = this.excursionId;
            instance.portOfCall = this.portOfCall;
            instance.excursionName = this.excursionName;
            instance.category = this.category;
            instance.durationHours = this.durationHours;
            instance.price = this.price;
            instance.maxCapacity = this.maxCapacity;
            instance.bookedCount = this.bookedCount;
            instance.difficultyLevel = this.difficultyLevel;
            instance.status = this.status;
            return instance;
        }
    }

}
