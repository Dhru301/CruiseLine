package com.cruiseline.modules.analytics.service;

import com.cruiseline.common.enums.BookingStatus;
import com.cruiseline.common.enums.ChargeStatus;
import com.cruiseline.modules.account.entity.OnboardAccount;
import com.cruiseline.modules.account.entity.OnboardCharge;
import com.cruiseline.modules.account.repository.OnboardAccountRepository;
import com.cruiseline.modules.account.repository.OnboardChargeRepository;
import com.cruiseline.modules.analytics.dto.VoyageAnalyticsResponse;
import com.cruiseline.modules.booking.entity.CruiseBooking;
import com.cruiseline.modules.booking.repository.CruiseBookingRepository;
import com.cruiseline.modules.excursion.repository.ExcursionBookingRepository;
import com.cruiseline.modules.voyage.entity.CabinCategory;
import com.cruiseline.modules.voyage.repository.CabinCategoryRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

/**
 * Computes voyage-level KPIs by aggregating across the booking,
 * excursion, voyage and account modules. Read-only.
 *
 * Counting rule: every non-cancelled booking (TENTATIVE / CONFIRMED /
 * COMPLETED) is counted, because those passengers occupy cabins and
 * represent committed revenue regardless of how much has been paid yet.
 */
@Service
public class AnalyticsService {

    private final CruiseBookingRepository bookingRepository;
    private final CabinCategoryRepository categoryRepository;
    private final ExcursionBookingRepository excursionBookingRepository;
    private final OnboardChargeRepository chargeRepository;
    private final OnboardAccountRepository accountRepository;

    @Transactional(readOnly = true)
    public VoyageAnalyticsResponse voyageAnalytics(Long voyageId) {
        // All bookings for the voyage that are not cancelled.
        List<CruiseBooking> active = bookingRepository.findByVoyageId(voyageId).stream()
                .filter(b -> b.getStatus() != BookingStatus.CANCELLED)
                .toList();

        long totalBookings = active.size();
        long totalPassengers = active.stream().mapToInt(CruiseBooking::getPaxCount).sum();

        BigDecimal totalRevenue = active.stream()
                .map(CruiseBooking::getTotalCost)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        // Occupancy = booked cabins / total cabins across the voyage's categories.
        // One booking occupies one cabin in this model. Clamped to 100% as a guard.
        List<CabinCategory> categories = categoryRepository.findByVoyageVoyageId(voyageId);
        int totalCabins = categories.stream().mapToInt(CabinCategory::getTotalCabins).sum();
        long soldCabins = totalBookings; // each booking = one cabin
        double occupancyRate = totalCabins == 0 ? 0.0
                : Math.min(100.0, round2((double) soldCabins / totalCabins * 100.0));

        BigDecimal revenuePerPassenger = totalPassengers == 0 ? BigDecimal.ZERO
                : totalRevenue.divide(BigDecimal.valueOf(totalPassengers), 2, RoundingMode.HALF_UP);

        // Excursion uptake = excursion bookings per passenger, expressed as a percentage.
        long excursionBookings = excursionBookingRepository.countByVoyageId(voyageId);
        double excursionUptake = totalPassengers == 0 ? 0.0
                : round2((double) excursionBookings / totalPassengers * 100.0);

        // Average onboard spend per passenger: sum of all live (POSTED) charges across
        // every account on this voyage, divided by the passenger count.
        BigDecimal totalOnboardSpend = BigDecimal.ZERO;
        for (OnboardAccount account : accountRepository.findByVoyageId(voyageId)) {
            for (OnboardCharge charge : chargeRepository.findByAccountId(account.getAccountId())) {
                if (charge.getStatus() == ChargeStatus.POSTED) {
                    totalOnboardSpend = totalOnboardSpend.add(charge.getAmount());
                }
            }
        }
        BigDecimal onboardSpendAvg = totalPassengers == 0 ? BigDecimal.ZERO
                : totalOnboardSpend.divide(BigDecimal.valueOf(totalPassengers), 2, RoundingMode.HALF_UP);

        return VoyageAnalyticsResponse.builder()
                .voyageId(voyageId)
                .occupancyRate(occupancyRate)
                .totalRevenue(totalRevenue)
                .revenuePerPassenger(revenuePerPassenger)
                .excursionUptakeRate(excursionUptake)
                .onboardSpendAvg(onboardSpendAvg)
                .totalBookings(totalBookings)
                .totalPassengers(totalPassengers)
                .build();
    }

    private double round2(double v) {
        return Math.round(v * 100.0) / 100.0;
    }

    public AnalyticsService(CruiseBookingRepository bookingRepository, CabinCategoryRepository categoryRepository, ExcursionBookingRepository excursionBookingRepository, OnboardChargeRepository chargeRepository, OnboardAccountRepository accountRepository) {
        this.bookingRepository = bookingRepository;
        this.categoryRepository = categoryRepository;
        this.excursionBookingRepository = excursionBookingRepository;
        this.chargeRepository = chargeRepository;
        this.accountRepository = accountRepository;
    }

}