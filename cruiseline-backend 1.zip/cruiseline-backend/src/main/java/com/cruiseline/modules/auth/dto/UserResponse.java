package com.cruiseline.modules.auth.dto;

import com.cruiseline.common.enums.Role;
import com.cruiseline.common.enums.UserStatus;
import com.cruiseline.modules.auth.entity.User;

public class UserResponse {
    private Long userId;
    private String name;
    private String email;
    private String phone;
    private Role role;
    private String vesselId;
    private UserStatus status;

    public static UserResponse from(User u) {
        return UserResponse.builder()
                .userId(u.getUserId())
                .name(u.getName())
                .email(u.getEmail())
                .phone(u.getPhone())
                .role(u.getRole())
                .vesselId(u.getVesselId())
                .status(u.getStatus())
                .build();
    }

    public UserResponse() {
    }

    public UserResponse(Long userId, String name, String email, String phone, Role role, String vesselId, UserStatus status) {
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.role = role;
        this.vesselId = vesselId;
        this.status = status;
    }

    public Long getUserId() {
        return this.userId;
    }

    public String getName() {
        return this.name;
    }

    public String getEmail() {
        return this.email;
    }

    public String getPhone() {
        return this.phone;
    }

    public Role getRole() {
        return this.role;
    }

    public String getVesselId() {
        return this.vesselId;
    }

    public UserStatus getStatus() {
        return this.status;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public void setVesselId(String vesselId) {
        this.vesselId = vesselId;
    }

    public void setStatus(UserStatus status) {
        this.status = status;
    }

    public static UserResponseBuilder builder() {
        return new UserResponseBuilder();
    }

    public static class UserResponseBuilder {
        private Long userId;
        private String name;
        private String email;
        private String phone;
        private Role role;
        private String vesselId;
        private UserStatus status;

        public UserResponseBuilder userId(Long userId) {
            this.userId = userId;
            return this;
        }
        public UserResponseBuilder name(String name) {
            this.name = name;
            return this;
        }
        public UserResponseBuilder email(String email) {
            this.email = email;
            return this;
        }
        public UserResponseBuilder phone(String phone) {
            this.phone = phone;
            return this;
        }
        public UserResponseBuilder role(Role role) {
            this.role = role;
            return this;
        }
        public UserResponseBuilder vesselId(String vesselId) {
            this.vesselId = vesselId;
            return this;
        }
        public UserResponseBuilder status(UserStatus status) {
            this.status = status;
            return this;
        }

        public UserResponse build() {
            UserResponse instance = new UserResponse();
            instance.userId = this.userId;
            instance.name = this.name;
            instance.email = this.email;
            instance.phone = this.phone;
            instance.role = this.role;
            instance.vesselId = this.vesselId;
            instance.status = this.status;
            return instance;
        }
    }

}
