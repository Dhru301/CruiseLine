package com.cruiseline.modules.voyage.dto;

import com.cruiseline.common.enums.CabinCategoryName;
import com.cruiseline.common.enums.CategoryStatus;
import com.cruiseline.modules.voyage.entity.CabinCategory;

import java.math.BigDecimal;

public class CabinCategoryResponse {
    private Long categoryId;
    private Long voyageId;
    private CabinCategoryName categoryName;
    private String deck;
    private String beddingConfig;
    private Integer maxOccupancy;
    private BigDecimal basePrice;
    private Integer totalCabins;
    private Integer availableCabins;
    private CategoryStatus status;

    public static CabinCategoryResponse from(CabinCategory c) {
        return CabinCategoryResponse.builder()
                .categoryId(c.getCategoryId())
                .voyageId(c.getVoyage().getVoyageId())
                .categoryName(c.getCategoryName())
                .deck(c.getDeck())
                .beddingConfig(c.getBeddingConfig())
                .maxOccupancy(c.getMaxOccupancy())
                .basePrice(c.getBasePrice())
                .totalCabins(c.getTotalCabins())
                .availableCabins(c.getAvailableCabins())
                .status(c.getStatus())
                .build();
    }

    public CabinCategoryResponse() {
    }

    public CabinCategoryResponse(Long categoryId, Long voyageId, CabinCategoryName categoryName, String deck, String beddingConfig, Integer maxOccupancy, BigDecimal basePrice, Integer totalCabins, Integer availableCabins, CategoryStatus status) {
        this.categoryId = categoryId;
        this.voyageId = voyageId;
        this.categoryName = categoryName;
        this.deck = deck;
        this.beddingConfig = beddingConfig;
        this.maxOccupancy = maxOccupancy;
        this.basePrice = basePrice;
        this.totalCabins = totalCabins;
        this.availableCabins = availableCabins;
        this.status = status;
    }

    public Long getCategoryId() {
        return this.categoryId;
    }

    public Long getVoyageId() {
        return this.voyageId;
    }

    public CabinCategoryName getCategoryName() {
        return this.categoryName;
    }

    public String getDeck() {
        return this.deck;
    }

    public String getBeddingConfig() {
        return this.beddingConfig;
    }

    public Integer getMaxOccupancy() {
        return this.maxOccupancy;
    }

    public BigDecimal getBasePrice() {
        return this.basePrice;
    }

    public Integer getTotalCabins() {
        return this.totalCabins;
    }

    public Integer getAvailableCabins() {
        return this.availableCabins;
    }

    public CategoryStatus getStatus() {
        return this.status;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public void setVoyageId(Long voyageId) {
        this.voyageId = voyageId;
    }

    public void setCategoryName(CabinCategoryName categoryName) {
        this.categoryName = categoryName;
    }

    public void setDeck(String deck) {
        this.deck = deck;
    }

    public void setBeddingConfig(String beddingConfig) {
        this.beddingConfig = beddingConfig;
    }

    public void setMaxOccupancy(Integer maxOccupancy) {
        this.maxOccupancy = maxOccupancy;
    }

    public void setBasePrice(BigDecimal basePrice) {
        this.basePrice = basePrice;
    }

    public void setTotalCabins(Integer totalCabins) {
        this.totalCabins = totalCabins;
    }

    public void setAvailableCabins(Integer availableCabins) {
        this.availableCabins = availableCabins;
    }

    public void setStatus(CategoryStatus status) {
        this.status = status;
    }

    public static CabinCategoryResponseBuilder builder() {
        return new CabinCategoryResponseBuilder();
    }

    public static class CabinCategoryResponseBuilder {
        private Long categoryId;
        private Long voyageId;
        private CabinCategoryName categoryName;
        private String deck;
        private String beddingConfig;
        private Integer maxOccupancy;
        private BigDecimal basePrice;
        private Integer totalCabins;
        private Integer availableCabins;
        private CategoryStatus status;

        public CabinCategoryResponseBuilder categoryId(Long categoryId) {
            this.categoryId = categoryId;
            return this;
        }
        public CabinCategoryResponseBuilder voyageId(Long voyageId) {
            this.voyageId = voyageId;
            return this;
        }
        public CabinCategoryResponseBuilder categoryName(CabinCategoryName categoryName) {
            this.categoryName = categoryName;
            return this;
        }
        public CabinCategoryResponseBuilder deck(String deck) {
            this.deck = deck;
            return this;
        }
        public CabinCategoryResponseBuilder beddingConfig(String beddingConfig) {
            this.beddingConfig = beddingConfig;
            return this;
        }
        public CabinCategoryResponseBuilder maxOccupancy(Integer maxOccupancy) {
            this.maxOccupancy = maxOccupancy;
            return this;
        }
        public CabinCategoryResponseBuilder basePrice(BigDecimal basePrice) {
            this.basePrice = basePrice;
            return this;
        }
        public CabinCategoryResponseBuilder totalCabins(Integer totalCabins) {
            this.totalCabins = totalCabins;
            return this;
        }
        public CabinCategoryResponseBuilder availableCabins(Integer availableCabins) {
            this.availableCabins = availableCabins;
            return this;
        }
        public CabinCategoryResponseBuilder status(CategoryStatus status) {
            this.status = status;
            return this;
        }

        public CabinCategoryResponse build() {
            CabinCategoryResponse instance = new CabinCategoryResponse();
            instance.categoryId = this.categoryId;
            instance.voyageId = this.voyageId;
            instance.categoryName = this.categoryName;
            instance.deck = this.deck;
            instance.beddingConfig = this.beddingConfig;
            instance.maxOccupancy = this.maxOccupancy;
            instance.basePrice = this.basePrice;
            instance.totalCabins = this.totalCabins;
            instance.availableCabins = this.availableCabins;
            instance.status = this.status;
            return instance;
        }
    }

}
