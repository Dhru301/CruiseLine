package com.cruiseline.modules.account.repository;

import com.cruiseline.modules.account.entity.FolioSettlement;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FolioSettlementRepository extends JpaRepository<FolioSettlement, Long> {
    List<FolioSettlement> findByAccountId(Long accountId);
}
