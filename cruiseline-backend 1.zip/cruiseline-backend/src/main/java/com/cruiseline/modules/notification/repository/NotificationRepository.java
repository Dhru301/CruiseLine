package com.cruiseline.modules.notification.repository;

import com.cruiseline.common.enums.NotificationStatus;
import com.cruiseline.modules.notification.entity.Notification;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NotificationRepository extends JpaRepository<Notification, Long> {
    Page<Notification> findByUserId(Long userId, Pageable pageable);
    Page<Notification> findByUserIdAndStatus(Long userId, NotificationStatus status, Pageable pageable);
    long countByUserIdAndStatus(Long userId, NotificationStatus status);
}
