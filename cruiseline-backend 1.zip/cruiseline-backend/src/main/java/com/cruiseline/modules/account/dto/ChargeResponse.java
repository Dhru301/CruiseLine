package com.cruiseline.modules.account.dto;

import com.cruiseline.common.enums.ChargeStatus;
import com.cruiseline.common.enums.ChargeType;
import com.cruiseline.modules.account.entity.OnboardCharge;

import java.math.BigDecimal;
import java.time.Instant;

public class ChargeResponse {
    private Long chargeId;
    private Long accountId;
    private ChargeType chargeType;
    private String description;
    private BigDecimal amount;
    private Instant postedDateTime;
    private Long postedById;
    private ChargeStatus status;

    public static ChargeResponse from(OnboardCharge c) {
        return ChargeResponse.builder()
                .chargeId(c.getChargeId())
                .accountId(c.getAccountId())
                .chargeType(c.getChargeType())
                .description(c.getDescription())
                .amount(c.getAmount())
                .postedDateTime(c.getPostedDateTime())
                .postedById(c.getPostedById())
                .status(c.getStatus())
                .build();
    }

    public ChargeResponse() {
    }

    public ChargeResponse(Long chargeId, Long accountId, ChargeType chargeType, String description, BigDecimal amount, Instant postedDateTime, Long postedById, ChargeStatus status) {
        this.chargeId = chargeId;
        this.accountId = accountId;
        this.chargeType = chargeType;
        this.description = description;
        this.amount = amount;
        this.postedDateTime = postedDateTime;
        this.postedById = postedById;
        this.status = status;
    }

    public Long getChargeId() {
        return this.chargeId;
    }

    public Long getAccountId() {
        return this.accountId;
    }

    public ChargeType getChargeType() {
        return this.chargeType;
    }

    public String getDescription() {
        return this.description;
    }

    public BigDecimal getAmount() {
        return this.amount;
    }

    public Instant getPostedDateTime() {
        return this.postedDateTime;
    }

    public Long getPostedById() {
        return this.postedById;
    }

    public ChargeStatus getStatus() {
        return this.status;
    }

    public void setChargeId(Long chargeId) {
        this.chargeId = chargeId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public void setChargeType(ChargeType chargeType) {
        this.chargeType = chargeType;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public void setPostedDateTime(Instant postedDateTime) {
        this.postedDateTime = postedDateTime;
    }

    public void setPostedById(Long postedById) {
        this.postedById = postedById;
    }

    public void setStatus(ChargeStatus status) {
        this.status = status;
    }

    public static ChargeResponseBuilder builder() {
        return new ChargeResponseBuilder();
    }

    public static class ChargeResponseBuilder {
        private Long chargeId;
        private Long accountId;
        private ChargeType chargeType;
        private String description;
        private BigDecimal amount;
        private Instant postedDateTime;
        private Long postedById;
        private ChargeStatus status;

        public ChargeResponseBuilder chargeId(Long chargeId) {
            this.chargeId = chargeId;
            return this;
        }
        public ChargeResponseBuilder accountId(Long accountId) {
            this.accountId = accountId;
            return this;
        }
        public ChargeResponseBuilder chargeType(ChargeType chargeType) {
            this.chargeType = chargeType;
            return this;
        }
        public ChargeResponseBuilder description(String description) {
            this.description = description;
            return this;
        }
        public ChargeResponseBuilder amount(BigDecimal amount) {
            this.amount = amount;
            return this;
        }
        public ChargeResponseBuilder postedDateTime(Instant postedDateTime) {
            this.postedDateTime = postedDateTime;
            return this;
        }
        public ChargeResponseBuilder postedById(Long postedById) {
            this.postedById = postedById;
            return this;
        }
        public ChargeResponseBuilder status(ChargeStatus status) {
            this.status = status;
            return this;
        }

        public ChargeResponse build() {
            ChargeResponse instance = new ChargeResponse();
            instance.chargeId = this.chargeId;
            instance.accountId = this.accountId;
            instance.chargeType = this.chargeType;
            instance.description = this.description;
            instance.amount = this.amount;
            instance.postedDateTime = this.postedDateTime;
            instance.postedById = this.postedById;
            instance.status = this.status;
            return instance;
        }
    }

}
