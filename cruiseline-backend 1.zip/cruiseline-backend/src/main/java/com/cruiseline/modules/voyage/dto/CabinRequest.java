package com.cruiseline.modules.voyage.dto;

import com.cruiseline.common.enums.CabinLocation;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class CabinRequest {
    @NotNull
    private Long categoryId;

    @NotBlank
    private String cabinNumber;

    private String deck;
    private CabinLocation location;

    public Long getCategoryId() {
        return this.categoryId;
    }

    public String getCabinNumber() {
        return this.cabinNumber;
    }

    public String getDeck() {
        return this.deck;
    }

    public CabinLocation getLocation() {
        return this.location;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public void setCabinNumber(String cabinNumber) {
        this.cabinNumber = cabinNumber;
    }

    public void setDeck(String deck) {
        this.deck = deck;
    }

    public void setLocation(CabinLocation location) {
        this.location = location;
    }

}
