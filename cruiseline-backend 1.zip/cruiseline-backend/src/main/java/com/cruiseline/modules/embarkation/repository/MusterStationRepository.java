package com.cruiseline.modules.embarkation.repository;

import com.cruiseline.modules.embarkation.entity.MusterStation;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MusterStationRepository extends JpaRepository<MusterStation, Long> {
    List<MusterStation> findByVoyageId(Long voyageId);
}
