package com.cruiseline.modules.embarkation.dto;

import com.cruiseline.common.enums.AttendanceStatus;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;

public class DrillAttendanceRequest {
    @NotNull
    private Long musterId;
    @NotNull
    private Long voyageId;
    @NotNull
    private Long passengerId;
    @NotNull
    private LocalDate drillDate;
    @NotNull
    private AttendanceStatus attendanceStatus;

    public Long getMusterId() {
        return this.musterId;
    }

    public Long getVoyageId() {
        return this.voyageId;
    }

    public Long getPassengerId() {
        return this.passengerId;
    }

    public LocalDate getDrillDate() {
        return this.drillDate;
    }

    public AttendanceStatus getAttendanceStatus() {
        return this.attendanceStatus;
    }

    public void setMusterId(Long musterId) {
        this.musterId = musterId;
    }

    public void setVoyageId(Long voyageId) {
        this.voyageId = voyageId;
    }

    public void setPassengerId(Long passengerId) {
        this.passengerId = passengerId;
    }

    public void setDrillDate(LocalDate drillDate) {
        this.drillDate = drillDate;
    }

    public void setAttendanceStatus(AttendanceStatus attendanceStatus) {
        this.attendanceStatus = attendanceStatus;
    }

}
