package com.cruiseline.modules.embarkation.controller;

import com.cruiseline.common.dto.ApiResponse;
import com.cruiseline.common.dto.PagedResponse;
import com.cruiseline.common.enums.EmbarkationStatus;
import com.cruiseline.config.UserPrincipal;
import com.cruiseline.modules.embarkation.dto.*;
import com.cruiseline.modules.embarkation.service.EmbarkationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "Embarkation & Muster", description = "Check-in, muster stations and drill attendance")
@RestController
@RequestMapping("/api/embarkation")
@PreAuthorize("hasAnyRole('EMBARKATION_OFFICER','ADMIN')")
public class EmbarkationController {

    private final EmbarkationService embarkationService;

    @Operation(summary = "Create a muster station")
    @PostMapping("/muster-stations")
    public ResponseEntity<ApiResponse<MusterStationResponse>> createStation(@Valid @RequestBody MusterStationRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Muster station created", embarkationService.createStation(req)));
    }

    @Operation(summary = "List muster stations for a voyage")
    @GetMapping("/voyages/{voyageId}/muster-stations")
    public ApiResponse<List<MusterStationResponse>> listStations(@PathVariable Long voyageId) {
        return ApiResponse.ok(embarkationService.listStations(voyageId));
    }

    @Operation(summary = "Check a passenger in (verifies documents, issues boarding pass)")
    @PostMapping("/check-in")
    public ResponseEntity<ApiResponse<EmbarkationResponse>> checkIn(@Valid @RequestBody CheckInRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Passenger checked in", embarkationService.checkIn(req)));
    }

    @Operation(summary = "Mark a checked-in passenger as onboard")
    @PatchMapping("/records/{recordId}/onboard")
    public ApiResponse<EmbarkationResponse> markOnboard(@PathVariable Long recordId) {
        return ApiResponse.ok("Marked onboard", embarkationService.markOnboard(recordId));
    }

    @Operation(summary = "Embarkation queue for a voyage (optional status filter)")
    @GetMapping("/voyages/{voyageId}/queue")
    public ApiResponse<PagedResponse<EmbarkationResponse>> queue(@PathVariable Long voyageId,
                                                               @RequestParam(required = false) EmbarkationStatus status,
                                                               Pageable pageable) {
        return ApiResponse.ok(embarkationService.queue(voyageId, status, pageable));
    }

    @Operation(summary = "Record muster drill attendance")
    @PostMapping("/drills")
    public ResponseEntity<ApiResponse<DrillAttendanceResponse>> recordAttendance(
            @AuthenticationPrincipal UserPrincipal principal,
            @Valid @RequestBody DrillAttendanceRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Attendance recorded",
                        embarkationService.recordAttendance(principal.getUserId(), req)));
    }

    @Operation(summary = "List drill attendance for a voyage")
    @GetMapping("/voyages/{voyageId}/drills")
    public ApiResponse<List<DrillAttendanceResponse>> drills(@PathVariable Long voyageId) {
        return ApiResponse.ok(embarkationService.drillAttendance(voyageId));
    }

    public EmbarkationController(EmbarkationService embarkationService) {
        this.embarkationService = embarkationService;
    }

}
