package com.cruiseline.modules.excursion.repository;

import com.cruiseline.modules.excursion.entity.ExcursionBooking;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ExcursionBookingRepository extends JpaRepository<ExcursionBooking, Long> {
    Page<ExcursionBooking> findByPassengerId(Long passengerId, Pageable pageable);
    List<ExcursionBooking> findByExcursionId(Long excursionId);
    long countByVoyageId(Long voyageId);
}
