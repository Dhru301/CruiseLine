package com.cruiseline.modules.excursion.dto;

import com.cruiseline.common.enums.ManifestStatus;
import com.cruiseline.modules.excursion.entity.ExcursionManifest;

import java.time.LocalDate;
import java.time.LocalTime;

public class ManifestResponse {
    private Long manifestId;
    private Long excursionId;
    private Long voyageId;
    private LocalDate portDate;
    private Integer totalBooked;
    private String meetingPoint;
    private LocalTime departureTime;
    private ManifestStatus status;

    public static ManifestResponse from(ExcursionManifest m) {
        return ManifestResponse.builder()
                .manifestId(m.getManifestId())
                .excursionId(m.getExcursionId())
                .voyageId(m.getVoyageId())
                .portDate(m.getPortDate())
                .totalBooked(m.getTotalBooked())
                .meetingPoint(m.getMeetingPoint())
                .departureTime(m.getDepartureTime())
                .status(m.getStatus())
                .build();
    }

    public ManifestResponse() {
    }

    public ManifestResponse(Long manifestId, Long excursionId, Long voyageId, LocalDate portDate, Integer totalBooked, String meetingPoint, LocalTime departureTime, ManifestStatus status) {
        this.manifestId = manifestId;
        this.excursionId = excursionId;
        this.voyageId = voyageId;
        this.portDate = portDate;
        this.totalBooked = totalBooked;
        this.meetingPoint = meetingPoint;
        this.departureTime = departureTime;
        this.status = status;
    }

    public Long getManifestId() {
        return this.manifestId;
    }

    public Long getExcursionId() {
        return this.excursionId;
    }

    public Long getVoyageId() {
        return this.voyageId;
    }

    public LocalDate getPortDate() {
        return this.portDate;
    }

    public Integer getTotalBooked() {
        return this.totalBooked;
    }

    public String getMeetingPoint() {
        return this.meetingPoint;
    }

    public LocalTime getDepartureTime() {
        return this.departureTime;
    }

    public ManifestStatus getStatus() {
        return this.status;
    }

    public void setManifestId(Long manifestId) {
        this.manifestId = manifestId;
    }

    public void setExcursionId(Long excursionId) {
        this.excursionId = excursionId;
    }

    public void setVoyageId(Long voyageId) {
        this.voyageId = voyageId;
    }

    public void setPortDate(LocalDate portDate) {
        this.portDate = portDate;
    }

    public void setTotalBooked(Integer totalBooked) {
        this.totalBooked = totalBooked;
    }

    public void setMeetingPoint(String meetingPoint) {
        this.meetingPoint = meetingPoint;
    }

    public void setDepartureTime(LocalTime departureTime) {
        this.departureTime = departureTime;
    }

    public void setStatus(ManifestStatus status) {
        this.status = status;
    }

    public static ManifestResponseBuilder builder() {
        return new ManifestResponseBuilder();
    }

    public static class ManifestResponseBuilder {
        private Long manifestId;
        private Long excursionId;
        private Long voyageId;
        private LocalDate portDate;
        private Integer totalBooked;
        private String meetingPoint;
        private LocalTime departureTime;
        private ManifestStatus status;

        public ManifestResponseBuilder manifestId(Long manifestId) {
            this.manifestId = manifestId;
            return this;
        }
        public ManifestResponseBuilder excursionId(Long excursionId) {
            this.excursionId = excursionId;
            return this;
        }
        public ManifestResponseBuilder voyageId(Long voyageId) {
            this.voyageId = voyageId;
            return this;
        }
        public ManifestResponseBuilder portDate(LocalDate portDate) {
            this.portDate = portDate;
            return this;
        }
        public ManifestResponseBuilder totalBooked(Integer totalBooked) {
            this.totalBooked = totalBooked;
            return this;
        }
        public ManifestResponseBuilder meetingPoint(String meetingPoint) {
            this.meetingPoint = meetingPoint;
            return this;
        }
        public ManifestResponseBuilder departureTime(LocalTime departureTime) {
            this.departureTime = departureTime;
            return this;
        }
        public ManifestResponseBuilder status(ManifestStatus status) {
            this.status = status;
            return this;
        }

        public ManifestResponse build() {
            ManifestResponse instance = new ManifestResponse();
            instance.manifestId = this.manifestId;
            instance.excursionId = this.excursionId;
            instance.voyageId = this.voyageId;
            instance.portDate = this.portDate;
            instance.totalBooked = this.totalBooked;
            instance.meetingPoint = this.meetingPoint;
            instance.departureTime = this.departureTime;
            instance.status = this.status;
            return instance;
        }
    }

}
