package com.cruiseline.modules.account.dto;

import com.cruiseline.common.enums.PaymentMode;
import com.cruiseline.common.enums.SettlementStatus;
import com.cruiseline.modules.account.entity.FolioSettlement;

import java.math.BigDecimal;
import java.time.Instant;

public class SettlementResponse {
    private Long settlementId;
    private Long accountId;
    private BigDecimal totalCharges;
    private BigDecimal totalCredits;
    private BigDecimal balanceSettled;
    private PaymentMode paymentMode;
    private Instant settlementDate;
    private SettlementStatus status;

    public static SettlementResponse from(FolioSettlement s) {
        return SettlementResponse.builder()
                .settlementId(s.getSettlementId())
                .accountId(s.getAccountId())
                .totalCharges(s.getTotalCharges())
                .totalCredits(s.getTotalCredits())
                .balanceSettled(s.getBalanceSettled())
                .paymentMode(s.getPaymentMode())
                .settlementDate(s.getSettlementDate())
                .status(s.getStatus())
                .build();
    }

    public SettlementResponse() {
    }

    public SettlementResponse(Long settlementId, Long accountId, BigDecimal totalCharges, BigDecimal totalCredits, BigDecimal balanceSettled, PaymentMode paymentMode, Instant settlementDate, SettlementStatus status) {
        this.settlementId = settlementId;
        this.accountId = accountId;
        this.totalCharges = totalCharges;
        this.totalCredits = totalCredits;
        this.balanceSettled = balanceSettled;
        this.paymentMode = paymentMode;
        this.settlementDate = settlementDate;
        this.status = status;
    }

    public Long getSettlementId() {
        return this.settlementId;
    }

    public Long getAccountId() {
        return this.accountId;
    }

    public BigDecimal getTotalCharges() {
        return this.totalCharges;
    }

    public BigDecimal getTotalCredits() {
        return this.totalCredits;
    }

    public BigDecimal getBalanceSettled() {
        return this.balanceSettled;
    }

    public PaymentMode getPaymentMode() {
        return this.paymentMode;
    }

    public Instant getSettlementDate() {
        return this.settlementDate;
    }

    public SettlementStatus getStatus() {
        return this.status;
    }

    public void setSettlementId(Long settlementId) {
        this.settlementId = settlementId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public void setTotalCharges(BigDecimal totalCharges) {
        this.totalCharges = totalCharges;
    }

    public void setTotalCredits(BigDecimal totalCredits) {
        this.totalCredits = totalCredits;
    }

    public void setBalanceSettled(BigDecimal balanceSettled) {
        this.balanceSettled = balanceSettled;
    }

    public void setPaymentMode(PaymentMode paymentMode) {
        this.paymentMode = paymentMode;
    }

    public void setSettlementDate(Instant settlementDate) {
        this.settlementDate = settlementDate;
    }

    public void setStatus(SettlementStatus status) {
        this.status = status;
    }

    public static SettlementResponseBuilder builder() {
        return new SettlementResponseBuilder();
    }

    public static class SettlementResponseBuilder {
        private Long settlementId;
        private Long accountId;
        private BigDecimal totalCharges;
        private BigDecimal totalCredits;
        private BigDecimal balanceSettled;
        private PaymentMode paymentMode;
        private Instant settlementDate;
        private SettlementStatus status;

        public SettlementResponseBuilder settlementId(Long settlementId) {
            this.settlementId = settlementId;
            return this;
        }
        public SettlementResponseBuilder accountId(Long accountId) {
            this.accountId = accountId;
            return this;
        }
        public SettlementResponseBuilder totalCharges(BigDecimal totalCharges) {
            this.totalCharges = totalCharges;
            return this;
        }
        public SettlementResponseBuilder totalCredits(BigDecimal totalCredits) {
            this.totalCredits = totalCredits;
            return this;
        }
        public SettlementResponseBuilder balanceSettled(BigDecimal balanceSettled) {
            this.balanceSettled = balanceSettled;
            return this;
        }
        public SettlementResponseBuilder paymentMode(PaymentMode paymentMode) {
            this.paymentMode = paymentMode;
            return this;
        }
        public SettlementResponseBuilder settlementDate(Instant settlementDate) {
            this.settlementDate = settlementDate;
            return this;
        }
        public SettlementResponseBuilder status(SettlementStatus status) {
            this.status = status;
            return this;
        }

        public SettlementResponse build() {
            SettlementResponse instance = new SettlementResponse();
            instance.settlementId = this.settlementId;
            instance.accountId = this.accountId;
            instance.totalCharges = this.totalCharges;
            instance.totalCredits = this.totalCredits;
            instance.balanceSettled = this.balanceSettled;
            instance.paymentMode = this.paymentMode;
            instance.settlementDate = this.settlementDate;
            instance.status = this.status;
            return instance;
        }
    }

}
